<?php
require __DIR__.'/config/app.php';
require __DIR__.'/views.php';
require __DIR__.'/admin.php';
require __DIR__.'/quality.php';
require __DIR__.'/analytics.php';
if(is_file(__DIR__.'/promotions.php')) require __DIR__.'/promotions.php';
require __DIR__.'/seo.php';
$route=requestRoute();
try { db(); }
catch(Throwable $e) { http_response_code(503); echo '<!doctype html><html lang="ru"><meta charset="utf-8"><title>Настройка Apex Detailing</title><h1>Подключение к базе не настроено</h1><p>Импортируйте db/install.sql в выбранную базу phpMyAdmin и заполните config/database.php согласно README.</p>'; exit; }
try {
 foreach([$_GET,$_POST] as $input)foreach($input as $v)if(!is_scalar($v)&&$v!==null)throw new AppError(400,'Некорректный формат запроса.');
 if(seoRoutes($route)) exit;
 if(analyticsRoutes($route)) exit;
 if(qualityRoutes($route)) exit;
 if(adminRoutes($route)) exit;
 if(function_exists('promotionRoutes') && promotionRoutes($route)) exit;
 if($route==='/favicon.ico') { http_response_code(204); exit; }
 if($route==='/robots.txt') { header('Content-Type: text/plain'); echo "User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /account\n"; exit; }
 if($route==='/logout') { postOnly(); checkCsrf(); $_SESSION=[]; session_regenerate_id(true); redirect('/'); }
 if(in_array($route,['/login','/register'],true)) {
  $register=$route==='/register'; $error=''; $next=safeNext($_POST['next']??$_GET['next']??'/account');
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf(); $email=mb_strtolower(trim($_POST['email']??'')); $password=$_POST['password']??''; $name=trim($_POST['name']??'');
   if($register) {
    if(mb_strlen($name)<2 || mb_strlen($name)>80) $error='Имя должно содержать от 2 до 80 символов.';
    elseif(!filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($email)>160) $error='Введите корректный email.';
    elseif(strlen($password)<8 || strlen($password)>72) $error='Пароль должен содержать от 8 до 72 байт.';
    elseif($password!==($_POST['confirm']??'')) $error='Пароли не совпадают.';
    else {
     try { query('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)',[$name,$email,password_hash($password,PASSWORD_DEFAULT)]); $uid=(int)db()->lastInsertId(); session_regenerate_id(true); $_SESSION['uid']=$uid; redirect($next); }
     catch(PDOException $e) { if($e->getCode()==='23000') $error='Этот email уже зарегистрирован.'; else throw $e; }
    }
   } else {
    $attempts=array_filter($_SESSION['attempts']??[],fn($t)=>$t>time()-300);
    if(count($attempts)>=10) $error='Слишком много попыток. Повторите вход через пять минут.';
    else {
     $u=query('SELECT * FROM users WHERE email=?',[$email])->fetch();
     if($u && strlen($password)<=128 && password_verify($password,$u['password_hash'])) { session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; unset($_SESSION['attempts']); redirect($next); }
     $_SESSION['attempts']=[...$attempts,time()]; $error='Неверный email или пароль.';
    }
   }
  }
  $title=$register?'Регистрация':'Вход в аккаунт'; $fields=$register?field('name','Ваше имя',$_POST['name']??'','text','required minlength="2" maxlength="80" autocomplete="name"'):'';
  $fields.=field('email','Email',$_POST['email']??'','email','required maxlength="160" autocomplete="email"').field('password','Пароль','','password','required minlength="8" maxlength="128" autocomplete="'.($register?'new-password':'current-password').'"');
  if($register) $fields.=field('confirm','Повторите пароль','','password','required minlength="8" autocomplete="new-password"');
  $nextQuery='?next='.rawurlencode($next);
  $switch=$register?'<p>Уже есть аккаунт? <a href="/login'.$nextQuery.'">Войти</a></p>':'<p>Впервые в студии? <a href="/register'.$nextQuery.'">Создать аккаунт</a></p>';
  render($title,'<div class="wrap page"><div class="auth"><h1>'.$title.'</h1><p>Сохраняйте записи и делитесь впечатлениями о визите.</p>'.notice($error,true).'<form class="form-grid" method="post">'.csrf().'<input type="hidden" name="next" value="'.esc($next).'">'.$fields.'<button class="primary">'.$title.'</button></form><div style="margin-top:24px">'.$switch.'</div></div></div>',$error?422:200);
 }
 if($route==='/api/reviews') {
  postOnly(); $u=needUser(); checkCsrf(); $s=service($_POST['service_id']??0);
  if(!hasVisit((int)$u['id'],(int)$s['id'])) throw new AppError(403,'Отзыв разрешён после выполненного визита на эту услугу.');
  $rating=(string)($_POST['rating']??''); $text=trim($_POST['text']??'');
  if(!in_array($rating,['1','2','3','4','5'],true) || mb_strlen($text)<3 || mb_strlen($text)>2000) throw new AppError(422,'Выберите оценку от 1 до 5 и введите от 3 до 2000 символов.');
  query('INSERT INTO reviews(service_id,user_id,rating,text,created_at) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE rating=VALUES(rating),text=VALUES(text),created_at=VALUES(created_at)',[$s['id'],$u['id'],(int)$rating,$text,time()]);
  $items=reviews((int)$s['id']); $avg=$items?round(array_sum(array_column($items,'rating'))/count($items),1):0;
  if(!str_contains($_SERVER['HTTP_ACCEPT']??'','application/json')) redirect('/service?id='.$s['id'].'#reviews');
  jsonResponse(['ok'=>true,'message'=>(query('SELECT is_published FROM reviews WHERE service_id=? AND user_id=?',[$s['id'],$u['id']])->fetchColumn()?'Отзыв сохранён.':'Изменения сохранены. Отзыв скрыт модератором и пока не публикуется.'),'html'=>implode('',array_map('reviewHtml',$items)),'rating'=>$items?number_format($avg,1,'.','').' из 5 · отзывов: '.count($items):'Пока нет оценок','aggregate'=>$items?['@type'=>'AggregateRating','ratingValue'=>$avg,'reviewCount'=>count($items),'bestRating'=>5,'worstRating'=>1]:null,'reviews'=>array_map(fn($r)=>['@type'=>'Review','author'=>['@type'=>'Person','name'=>$r['name']],'reviewBody'=>$r['text'],'reviewRating'=>['@type'=>'Rating','ratingValue'=>(int)$r['rating'],'bestRating'=>5,'worstRating'=>1]],$items)]);
 }
 if($route==='/booking') {
  if(!currentUser()) redirect('/login?next='.rawurlencode('/booking?id='.(int)($_GET['id']??$_POST['service_id']??0))); $u=needUser(); $s=service($_GET['id']??$_POST['service_id']??0); if(!$s['is_active'])throw new AppError(409,'Услуга находится в архиве и недоступна для новой записи.'); $p=offer((int)$s['id']); $price=(int)($p['sale_price']??$s['price']); $error=''; $status=200;
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf(); $token=(string)($_POST['request_token']??''); $quote=$_SESSION['quotes'][$token]??null;
   if(query('SELECT id FROM bookings WHERE request_token=? AND user_id=?',[$token,$u['id']])->fetch()) redirect('/account?saved=1');
   $car=trim($_POST['car']??''); $phone=trim($_POST['phone']??'');
   if(!$quote || $quote['service_id']!=(int)$s['id']) $error='Форма записи устарела. Заполните новую форму.';
   elseif(mb_strlen($car)<2 || mb_strlen($car)>100) $error='Укажите марку и модель автомобиля.';
   elseif(!preg_match('/^\+?\d[\d ()-]{8,20}$/',$phone)) $error='Укажите корректный телефон.';
   else {
    try { $visit=inputEpoch($_POST['visit_at']??''); $hour=(int)(new DateTimeImmutable('@'.$visit))->setTimezone(new DateTimeZone(MOSCOW))->format('H'); if($visit<=time() || $hour<9 || $hour>=20) $error='Выберите будущую дату с временем от 09:00 до 19:59 МСК.'; }
    catch(AppError $e) { $error=$e->getMessage(); }
   }
   if(!$error) {
    $pdo=db(); $pdo->beginTransaction();
    try {
     // Serialize booking and promotion edits through the service row lock.
     $s=query('SELECT * FROM services WHERE id=? FOR UPDATE',[$s['id']])->fetch();
     if(!$s||!$s['is_active'])throw new AppError(409,'Услуга больше недоступна для записи.');
     $p=offer((int)$s['id']); $price=(int)($p['sale_price']??$s['price']);
     if($quote['price']!==$price) { $pdo->rollBack(); $error='Цена изменилась. Проверьте новую сумму и подтвердите запись повторно.'; $status=409; }
     else {
      $columns='user_id,service_id,car,phone,visit_at,price,request_token,created_at';
      $data=[$u['id'],$s['id'],$car,$phone,$visit,$price,$token,time()];
      if(function_exists('bestOffer')) { $columns.=',base_price,promotion_id,promotion_title'; array_push($data,$s['price'],$p['id']??null,$p['title']??''); }
      query('INSERT INTO bookings ('.$columns.') VALUES ('.implode(',',array_fill(0,count($data),'?')).')',$data); $bookingId=(int)$pdo->lastInsertId(); $pdo->commit(); analyticsReceipt($bookingId,(int)$s['id'],$price); unset($_SESSION['quotes'][$token]); redirect('/account?saved=1');
     }
    } catch(Throwable $e) { if($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
   }
   if($error && $status===200) $status=422;
  }
  $token=bin2hex(random_bytes(24)); if(count($_SESSION['quotes']??[])>30) $_SESSION['quotes']=[];
  $_SESSION['quotes'][$token]=['service_id'=>(int)$s['id'],'price'=>$price];
  $fields=field('car','Марка и модель',$_POST['car']??'','text','required maxlength="100" placeholder="Например, Skoda Octavia"').field('phone','Телефон',$_POST['phone']??'','tel','required maxlength="24" placeholder="+7 999 123-45-67"').field('visit_at','Дата и время визита',$_POST['visit_at']??'','datetime-local','required min="'.inputDate(time()+60).'"');
  $body='<div class="split"><div><p>Оставьте заявку. Время визита подтверждает администратор студии.</p>'.notice($error,true).'<form class="form-grid" method="post">'.csrf().'<input type="hidden" name="service_id" value="'.$s['id'].'"><input type="hidden" name="request_token" value="'.$token.'">'.$fields.'<div class="help">Время по Москве, приём с 09:00 до 20:00. Заявка без предоплаты. Время согласует администратор.</div><button class="primary">Подтвердить запись</button></form></div><aside class="summary"><img src="/assets/images/'.esc($s['image']).'" alt="'.esc($s['name']).'"><h3>'.esc($s['name']).'</h3><p>'.$s['duration'].' минут</p>'.prices($s,$p).'<p style="margin-top:14px">Цена фиксируется при сохранении заявки.</p></aside></div>';
  render('Онлайн запись',page('Записать автомобиль',$body),$status);
 }
 if(in_array($route,['/service','/api/service'],true)) {
  $s=service($_GET['id']??0); $p=offer((int)$s['id']); $items=reviews((int)$s['id']); $count=count($items); $avg=$count?round(array_sum(array_column($items,'rating'))/$count,1):0;
  $list=$count?implode('',array_map('reviewHtml',$items)):'<p>Отзывов пока нет. Ваш отзыв может стать первым.</p>';
  if($route==='/api/service') {
   $content='<h2>'.esc($s['name']).'</h2><div class="dialog-image">'.imageMarkup($s,'card').'</div><div class="tabs" role="tablist"><button role="tab" aria-selected="true" data-tab="description">Описание</button><button role="tab" aria-selected="false" data-tab="reviews">Отзывы ('.$count.')</button></div><div data-panel="description"><p>'.esc($s['description']).'</p>'.prices($s,$p).'</div><div data-panel="reviews" hidden>'.$list.'</div><p><a class="button primary" href="/service?id='.$s['id'].'#reviews">Все отзывы и форма</a></p>';
   jsonResponse(['ok'=>true,'html'=>$content]);
  }
  $u=currentUser(); $own=$u?query('SELECT * FROM reviews WHERE user_id=? AND service_id=?',[$u['id'],$s['id']])->fetch():null;
  if(!$u) $form=notice('Для публикации отзыва войдите в аккаунт.').'<a class="button" href="/login?next='.rawurlencode('/service?id='.$s['id'].'#reviews').'">Войти</a>';
  elseif(!hasVisit((int)$u['id'],(int)$s['id'])) $form=notice('Отзыв доступен после выполненного визита на эту услугу.');
  else {
   $stars=''; foreach([5,4,3,2,1] as $r) $stars.='<input type="radio" id="rating-'.$r.'" name="rating" value="'.$r.'" '.($own && (int)$own['rating']===$r?'checked':'').' required><label for="rating-'.$r.'" title="'.$r.' из 5">★</label>';
   $form=($own&&!$own['is_published']?notice('Отзыв скрыт модератором. Изменения можно сохранить; публикацию восстановит администратор.'):'').'<form action="/api/reviews" method="post" class="form-grid" data-review-form>'.csrf().'<input type="hidden" name="service_id" value="'.$s['id'].'"><fieldset><legend>Ваша оценка</legend><div class="stars-input">'.$stars.'</div></fieldset><div><label for="review-text">Ваш отзыв</label><textarea id="review-text" class="ym-disable-keys" name="text" minlength="3" maxlength="2000" required>'.esc($own['text']??'').'</textarea><div class="help"><span data-character-count>0</span>/2000 · От 3 до 2000 символов. Повторная отправка обновит ваш отзыв.</div></div><button class="primary">'.($own?'Обновить отзыв':'Отправить отзыв').'</button><div data-form-status role="status"></div></form>';
  }
  $rating=$count?number_format($avg,1,'.','').' из 5 · отзывов: '.$count:'Пока нет оценок';
  $label=$p?'<a class="promo-label '.$p['type'].'" href="/promotions#promo-'.$p['id'].'">'.TYPES[$p['type']].'</a><div class="timer" data-end="'.$p['ends_at'].'">До '.localDate($p['ends_at']).'</div>':'';
  $label='<div data-service-offer="'.$s['id'].'">'.$label.'</div>';
  $inclusions=''; foreach(explode(';',$s['details']) as $x) $inclusions.='<li>'.esc($x).'</li>';
  $detail='<div class="details">'.imageMarkup($s,'detail').'<div><div class="meta">'.esc($s['category']).' · '.$s['duration'].' минут</div><h1>'.esc($s['name']).'</h1><p>'.esc($s['description']).'</p><div class="meta" data-rating>'.$rating.'</div>'.$label.prices($s,$p).'<h2 class="service-inclusions-heading" style="margin-top:24px">Что входит в услугу</h2><ul class="inclusions">'.$inclusions.'</ul>'.($s['is_active']?'<a class="button primary" href="/booking?id='.$s['id'].'">Записаться на услугу ↗</a>':notice('Услуга находится в архиве. Новые записи закрыты.')).'</div></div><section class="reviews-layout" id="reviews"><div><h2>Отзывы клиентов</h2><div data-review-list>'.$list.'</div></div><div><h2>Ваш опыт</h2>'.$form.'</div></section>';
  $ld=['@context'=>'https://schema.org','@type'=>'Service','name'=>$s['name'],'description'=>$s['description'],'image'=>absoluteUrl(imageData($s)['webp']),'provider'=>['@type'=>'AutoRepair','name'=>'Apex Detailing'],'offers'=>['@type'=>'Offer','price'=>number_format(($p['sale_price']??$s['price'])/100,2,'.',''),'priceCurrency'=>'RUB','url'=>absoluteUrl('/service?id='.$s['id'])]];
  if($count) { $ld['aggregateRating']=['@type'=>'AggregateRating','ratingValue'=>$avg,'reviewCount'=>$count,'bestRating'=>5,'worstRating'=>1]; $ld['review']=array_map(fn($r)=>['@type'=>'Review','author'=>['@type'=>'Person','name'=>$r['name']],'reviewRating'=>['@type'=>'Rating','ratingValue'=>(int)$r['rating'],'bestRating'=>5,'worstRating'=>1],'reviewBody'=>$r['text'],'datePublished'=>gmdate('c',$r['created_at'])],$items); }
  render($s['name'].' — цена и отзывы','<div class="wrap page"><div class="breadcrumbs"><a href="/services">Услуги</a> / '.esc($s['name']).'</div>'.$detail.'</div>',200,$s['description'].' Цена '.money($p['sale_price']??$s['price']).'. Отзывы и онлайн-запись.',$ld);
 }
 throw new AppError(404,'Страница не найдена.');
} catch(AppError $e) {
 if(str_starts_with($route,'/api/')) jsonResponse(['ok'=>false,'message'=>$e->getMessage()],$e->status);
 render('Проверка запроса',page('Не удалось выполнить действие',notice($e->getMessage(),true).'<a class="button" href="/">На главную</a>'),$e->status);
} catch(Throwable $e) {
 error_log((string)$e); if(str_starts_with($route,'/api/')) jsonResponse(['ok'=>false,'message'=>'Сервис временно недоступен.'],500);
 render('Ошибка сервера',page('Сервис временно недоступен','<p>Повторите попытку позже.</p>'),500);
}
