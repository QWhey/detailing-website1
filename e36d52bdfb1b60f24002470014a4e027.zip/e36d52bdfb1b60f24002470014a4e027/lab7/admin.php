<?php
function adminNav(string $active='dashboard'): string {
 $items=[
  'dashboard'=>['/admin','Обзор'],
  'bookings'=>['/admin/bookings','Записи'],
  'services'=>['/admin/services','Услуги'],
  'users'=>['/admin/users','Пользователи'],
  'reviews'=>['/admin/reviews','Отзывы'],
 ];
 if(function_exists('bestOffer')) $items['promotions']=['/admin/promotions','Акции'];
 if(function_exists('seoRoutes'))$items['settings']=['/admin/settings','Настройки'];
 $items['analytics']=['/admin/analytics','Аналитика'];
 $html='<nav class="admin-nav" aria-label="Разделы админ-панели">';
 foreach($items as $key=>$item) $html.='<a class="'.($active===$key?'active':'').'" href="'.$item[0].'">'.$item[1].'</a>';
 return $html.'<a href="/">На сайт</a></nav>';
}
function adminPage(string $title,string $content,string $active='dashboard',int $status=200): never {
 render($title,'<div class="wrap page admin-page"><div class="admin-heading"><div><div class="eyebrow">APEX CONTROL</div><h1>'.$title.'</h1></div><a class="button" href="/">Открыть сайт</a></div>'.adminNav($active).takeFlash().$content.'</div>',$status);
}
function rublesToKopecks(string $value): int {
 $value=trim(str_replace(' ','',$value));
 if(!preg_match('/^(\d{1,8})(?:[.,](\d{1,2}))?$/',$value,$m)) throw new AppError(422,'Введите корректную цену в рублях.');
 return (int)$m[1]*100+(int)str_pad($m[2]??'',2,'0');
}
function adminRoutes(string $route): bool {
 if($route==='/admin/login') {
  if(($u=currentUser()) && $u['role']==='admin') redirect('/admin');
  $error='';
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf(); $email=mb_strtolower(trim($_POST['email']??'')); $password=(string)($_POST['password']??'');
   $attempts=array_filter($_SESSION['admin_attempts']??[],fn($t)=>$t>time()-300);
   if(count($attempts)>=10) $error='Слишком много попыток. Повторите вход через пять минут.';
   else {
    $u=query('SELECT * FROM users WHERE email=?',[$email])->fetch();
    if($u && $u['role']==='admin' && strlen($password)<=128 && password_verify($password,$u['password_hash'])) {
     session_regenerate_id(true); $_SESSION['uid']=(int)$u['id']; unset($_SESSION['admin_attempts']); redirect('/admin');
    }
    $_SESSION['admin_attempts']=[...$attempts,time()]; $error='Неверные данные администратора.';
   }
  }
  $form='<div class="admin-login"><div class="eyebrow">APEX CONTROL</div><h1>Вход администратора</h1><p>Управление услугами, клиентами, записями и отзывами.</p>'.notice($error,true).'<form method="post" class="form-grid">'.csrf().field('email','Email администратора',$_POST['email']??'','email','required autocomplete="email"').field('password','Пароль','','password','required minlength="8" autocomplete="current-password"').'<button class="primary">Войти в панель</button></form><p class="help" style="margin-top:18px"><a href="/">Вернуться на сайт</a></p></div>';
  render('Вход администратора','<div class="wrap page">'.$form.'</div>',$error?422:200); return true;
 }
 if(!str_starts_with($route,'/admin')) return false;
 if(!currentUser()) redirect('/admin/login'); needAdmin();

 if($route==='/admin') {
  $stats=[
   'users'=>(int)query("SELECT COUNT(*) FROM users WHERE role='customer'")->fetchColumn(),
   'services'=>(int)query('SELECT COUNT(*) FROM services')->fetchColumn(),
   'new'=>(int)query("SELECT COUNT(*) FROM bookings WHERE status='new'")->fetchColumn(),
   'completed'=>(int)query("SELECT COUNT(*) FROM bookings WHERE status='completed'")->fetchColumn(),
   'reviews'=>(int)query('SELECT COUNT(*) FROM reviews')->fetchColumn(),
   'revenue'=>(int)query("SELECT COALESCE(SUM(price),0) FROM bookings WHERE status='completed'")->fetchColumn(),
  ];
  $cards='<div class="admin-stats">'
   .'<div class="admin-stat"><span>Клиенты</span><strong>'.$stats['users'].'</strong><a href="/admin/users">Открыть</a></div>'
   .'<div class="admin-stat"><span>Новые записи</span><strong>'.$stats['new'].'</strong><a href="/admin/bookings?status=new">Обработать</a></div>'
   .'<div class="admin-stat"><span>Выполнено</span><strong>'.$stats['completed'].'</strong><a href="/admin/bookings?status=completed">История</a></div>'
   .'<div class="admin-stat"><span>Услуги</span><strong>'.$stats['services'].'</strong><a href="/admin/services">Управлять</a></div>'
   .'<div class="admin-stat"><span>Отзывы</span><strong>'.$stats['reviews'].'</strong><a href="/admin/reviews">Модерация</a></div>'
   .'<div class="admin-stat"><span>Выручка по выполненным</span><strong class="money-stat">'.money($stats['revenue']).'</strong><a href="/admin/bookings">Все записи</a></div></div>';
  $recent=query('SELECT b.*,u.name customer,s.name service FROM bookings b JOIN users u ON u.id=b.user_id JOIN services s ON s.id=b.service_id ORDER BY b.id DESC LIMIT 8')->fetchAll();
  $rows=''; foreach($recent as $b) $rows.='<tr><td>#'.$b['id'].'</td><td>'.esc($b['customer']).'</td><td>'.esc($b['service']).'</td><td>'.localDate($b['visit_at']).'</td><td><span class="status '.$b['status'].'">'.STATUS[$b['status']].'</span></td><td>'.money($b['price']).'</td></tr>';
  $quick='<div class="admin-section-head"><h2>Последние записи</h2><a class="button small" href="/admin/bookings">Все записи</a></div><div class="table-scroll"><table class="data-table"><thead><tr><th>ID</th><th>Клиент</th><th>Услуга</th><th>Визит</th><th>Статус</th><th>Сумма</th></tr></thead><tbody>'.($rows?:'<tr><td colspan="6">Записей пока нет.</td></tr>').'</tbody></table></div>';
  adminPage('Админ-панель',$cards.$quick,'dashboard');
 }

 if($route==='/admin/bookings') {
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf(); $id=(int)($_POST['id']??0); $action=$_POST['action']??'status';
   $item=query('SELECT id FROM bookings WHERE id=?',[$id])->fetch(); if(!$item) throw new AppError(404,'Запись не найдена.');
   if($action==='cancel') query("UPDATE bookings SET status='cancelled' WHERE id=? AND status='new'",[$id]);
   elseif($action==='delete')throw new AppError(422,'История визитов не удаляется. Используйте отмену заявки.');
   else { $status=$_POST['status']??''; if(!isset(STATUS[$status])) throw new AppError(422,'Неизвестный статус.'); query('UPDATE bookings SET status=? WHERE id=?',[$status,$id]); }
   redirect('/admin/bookings');
  }
  $status=$_GET['status']??''; $q=trim($_GET['q']??''); $where=[];$params=[];
  if($status!=='' && isset(STATUS[$status])) {$where[]='b.status=?';$params[]=$status;}
  if($q!=='') {$where[]='(u.name LIKE ? OR u.email LIKE ? OR b.phone LIKE ? OR b.car LIKE ? OR s.name LIKE ?)';$like='%'.$q.'%';array_push($params,$like,$like,$like,$like,$like);}
  $sql='SELECT b.*,u.name customer,u.email,s.name service FROM bookings b JOIN users u ON u.id=b.user_id JOIN services s ON s.id=b.service_id'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY b.id DESC';
  $items=query($sql,$params)->fetchAll(); $rows='';
  foreach($items as $b) { $opts=''; foreach(STATUS as $key=>$label)$opts.='<option value="'.$key.'" '.($key===$b['status']?'selected':'').'>'.$label.'</option>';
   $rows.='<tr><td>#'.$b['id'].'<br><span class="meta">'.localDate($b['created_at']).'</span></td><td><strong>'.esc($b['customer']).'</strong><br>'.esc($b['email']).'<br>'.esc($b['phone']).'</td><td>'.esc($b['service']).'<br><span class="meta">'.esc($b['car']).'</span></td><td>'.localDate($b['visit_at']).'</td><td>'.money($b['price']).'</td><td><form method="post" class="actions">'.csrf().'<input type="hidden" name="id" value="'.$b['id'].'"><select name="status" aria-label="Статус записи">'.$opts.'</select><button class="small">Сохранить</button></form></td><td><form method="post" data-confirm="Отменить ожидающую заявку? История сохранится.">'.csrf().'<input type="hidden" name="id" value="'.$b['id'].'"><input type="hidden" name="action" value="cancel"><button class="small danger">Отменить</button></form></td></tr>'; }
  $opts='<option value="">Все статусы</option>'; foreach(STATUS as $key=>$label)$opts.='<option value="'.$key.'" '.($status===$key?'selected':'').'>'.$label.'</option>';
  $filter='<form class="filters" method="get"><input aria-label="Поиск" name="q" value="'.esc($q).'" placeholder="Клиент, email, авто, телефон или услуга"><select name="status" aria-label="Статус записи">'.$opts.'</select><button>Найти</button><a class="button" href="/admin/bookings">Сбросить</a></form>';
  adminPage('Записи клиентов',$filter.'<div class="table-scroll"><table class="data-table"><thead><tr><th>Запись</th><th>Клиент</th><th>Услуга / авто</th><th>Визит МСК</th><th>Цена</th><th>Статус</th><th></th></tr></thead><tbody>'.($rows?:'<tr><td colspan="7">Ничего не найдено.</td></tr>').'</tbody></table></div>','bookings');
 }

 if($route==='/admin/services') {
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf(); $id=(int)($_POST['id']??0); $action=$_POST['action']??'';
   if(!in_array($action,['archive','restore'],true))throw new AppError(422,'Неизвестное действие.');
   if(!query('SELECT id FROM services WHERE id=?',[$id])->fetch())throw new AppError(404,'Услуга не найдена.');
   query('UPDATE services SET is_active=? WHERE id=?',[$action==='restore'?1:0,$id]);
   flash($action==='restore'?'Услуга возвращена в каталог.':'Услуга скрыта из каталога. История визитов сохранена.');redirect('/admin/services');
  }
  $q=trim($_GET['q']??''); $items=$q===''?query('SELECT * FROM services ORDER BY id DESC')->fetchAll():query('SELECT * FROM services WHERE name LIKE ? OR category LIKE ? ORDER BY id DESC',['%'.$q.'%','%'.$q.'%'])->fetchAll(); $rows='';
  foreach($items as $s) $rows.='<tr><td>#'.$s['id'].'</td><td><strong>'.esc($s['name']).'</strong><br><span class="meta">'.esc($s['category']).'</span><br><span class="status '.($s['is_active']?'completed':'cancelled').'">'.($s['is_active']?'В каталоге':'В архиве').'</span></td><td class="description">'.esc($s['description']).'</td><td>'.money($s['price']).'</td><td>'.$s['duration'].' мин.</td><td><div class="actions"><a class="button small" href="/admin/services/edit?id='.$s['id'].'">Изменить</a><a class="button small" href="/service?id='.$s['id'].'">На сайте</a><a class="button small" href="/admin/services/seo?id='.$s['id'].'">SEO изображения</a><form method="post" data-confirm="Изменить доступность услуги? История визитов сохранится.">'.csrf().'<input type="hidden" name="id" value="'.$s['id'].'"><input type="hidden" name="action" value="'.($s['is_active']?'archive':'restore').'"><button class="small '.($s['is_active']?'danger':'').'">'.($s['is_active']?'В архив':'В каталог').'</button></form></div></td></tr>';
  $top='<div class="admin-toolbar"><form class="filters" method="get"><input aria-label="Поиск" name="q" value="'.esc($q).'" placeholder="Поиск услуги"><button>Найти</button></form><a class="button primary" href="/admin/services/edit">Добавить услугу</a></div>';
  adminPage('Услуги',$top.'<div class="table-scroll"><table class="data-table"><thead><tr><th>ID</th><th>Услуга</th><th>Описание</th><th>Цена</th><th>Время</th><th>Действия</th></tr></thead><tbody>'.($rows?:'<tr><td colspan="6">Услуг нет.</td></tr>').'</tbody></table></div>','services');
 }

 if($route==='/admin/services/edit') {
  $id=(int)($_GET['id']??0); $old=$id?query('SELECT * FROM services WHERE id=?',[$id])->fetch():null; if($id&&!$old)throw new AppError(404,'Услуга не найдена.');
  $v=$old?:['name'=>'','description'=>'','details'=>'','price'=>100000,'duration'=>60,'image'=>'wash.webp','category'=>'Кузов']; $error=''; $priceText=number_format($v['price']/100,2,'.','');
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf(); $v=array_merge($v,$_POST); $priceText=$_POST['price']??'';
   try { $name=trim($_POST['name']??'');$description=trim($_POST['description']??'');$details=trim($_POST['details']??'');$category=trim($_POST['category']??'');$duration=(int)($_POST['duration']??0);$image=$_POST['image']??'';$price=rublesToKopecks($priceText); if($price<1||$price>100000000)throw new AppError(422,'Цена должна быть от 0,01 до 1 000 000 ₽.');
    if(mb_strlen($name)<2||mb_strlen($name)>120)throw new AppError(422,'Название должно содержать от 2 до 120 символов.');
    if(mb_strlen($description)<3||mb_strlen($description)>2000)throw new AppError(422,'Описание должно содержать от 3 до 2000 символов.');
    if(mb_strlen($details)<3||mb_strlen($details)>5000)throw new AppError(422,'Укажите, что входит в услугу. Пункты разделяйте точкой с запятой.');
    if($duration<10||$duration>1440)throw new AppError(422,'Длительность должна быть от 10 до 1440 минут.');
    if(mb_strlen($category)<2||mb_strlen($category)>40)throw new AppError(422,'Укажите категорию.');
    if(!in_array($image,['wash.webp','polish.webp','interior.webp','hero.webp'],true))throw new AppError(422,'Выберите изображение из списка.');
    $data=[$name,$description,$details,$price,$duration,$image,$category];
    if($id){$data[]=$id;db()->beginTransaction();try{query('SELECT id FROM services WHERE id=? FOR UPDATE',[$id]);query('UPDATE services SET name=?,description=?,details=?,price=?,duration=?,image=?,category=? WHERE id=?',$data);db()->commit();}catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}} else query('INSERT INTO services(name,description,details,price,duration,image,category) VALUES(?,?,?,?,?,?,?)',$data);
    redirect('/admin/services');
   } catch(AppError $e){$error=$e->getMessage();}
  }
  $images='';foreach(['wash.webp'=>'Мойка','polish.webp'=>'Полировка','interior.webp'=>'Салон','hero.webp'=>'Студия'] as $key=>$label)$images.='<option value="'.$key.'" '.($v['image']===$key?'selected':'').'>'.$label.'</option>';
  $form=notice($error,true).'<form method="post" class="form-grid">'.csrf().field('name','Название',$v['name'],'text','required maxlength="120"').'<div><label for="description">Краткое описание</label><textarea id="description" name="description" required maxlength="2000">'.esc($v['description']).'</textarea></div><div><label for="details">Что входит</label><textarea id="details" name="details" required>'.esc($v['details']).'</textarea><div class="help">Разделяйте пункты точкой с запятой.</div></div><div class="row">'.field('price','Цена, ₽',$priceText,'text','required inputmode="decimal"').field('duration','Длительность, минут',$v['duration'],'number','required min="10" max="1440"').'</div><div class="row">'.field('category','Категория',$v['category'],'text','required maxlength="40"').'<div><label for="image">Изображение</label><select id="image" name="image">'.$images.'</select></div></div><div class="actions"><button class="primary">Сохранить</button><a class="button" href="/admin/services">Отмена</a></div></form>';
  adminPage($id?'Редактировать услугу':'Новая услуга','<div class="admin-form-card">'.$form.'</div>','services',$error?422:200);
 }

 if($route==='/admin/users') {
  $me=needAdmin();
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf();$id=(int)($_POST['id']??0);$action=$_POST['action']??'role';$target=query('SELECT * FROM users WHERE id=?',[$id])->fetch();if(!$target)throw new AppError(404,'Пользователь не найден.');
   if($action==='delete') { if($id===(int)$me['id'])throw new AppError(422,'Нельзя удалить собственный аккаунт.'); if((int)query('SELECT COUNT(*) FROM bookings WHERE user_id=?',[$id])->fetchColumn()>0)throw new AppError(409,'Нельзя удалить пользователя с историей записей.'); query('DELETE FROM users WHERE id=?',[$id]); }
   else { $role=$_POST['role']??'';if(!in_array($role,['customer','admin'],true))throw new AppError(422,'Некорректная роль.');if($id===(int)$me['id']&&$role!=='admin')throw new AppError(422,'Нельзя снять роль администратора с собственного аккаунта.');query('UPDATE users SET role=? WHERE id=?',[$role,$id]); }
   redirect('/admin/users');
  }
  $q=trim($_GET['q']??'');$params=[];$sql='SELECT u.*,COUNT(DISTINCT b.id) bookings_count,COUNT(DISTINCT r.id) reviews_count FROM users u LEFT JOIN bookings b ON b.user_id=u.id LEFT JOIN reviews r ON r.user_id=u.id';if($q!==''){$sql.=' WHERE u.name LIKE ? OR u.email LIKE ?';$params=['%'.$q.'%','%'.$q.'%'];}$sql.=' GROUP BY u.id ORDER BY u.id DESC';$items=query($sql,$params)->fetchAll();$rows='';
  foreach($items as $u){$roles='<option value="customer" '.($u['role']==='customer'?'selected':'').'>Клиент</option><option value="admin" '.($u['role']==='admin'?'selected':'').'>Администратор</option>';$rows.='<tr><td>#'.$u['id'].'</td><td><strong>'.esc($u['name']).'</strong><br>'.esc($u['email']).'</td><td>'.$u['bookings_count'].'</td><td>'.$u['reviews_count'].'</td><td><form method="post" class="actions">'.csrf().'<input type="hidden" name="id" value="'.$u['id'].'"><select name="role" aria-label="Роль пользователя">'.$roles.'</select><button class="small">Сохранить</button></form></td><td>'.((int)$u['id']===(int)$me['id']?'<span class="meta">Текущий аккаунт</span>':'<form method="post" data-confirm="Удалить этого пользователя?">'.csrf().'<input type="hidden" name="id" value="'.$u['id'].'"><input type="hidden" name="action" value="delete"><button class="small danger">Удалить</button></form>').'</td></tr>';}
  adminPage('Пользователи','<form class="filters" method="get"><input aria-label="Поиск" name="q" value="'.esc($q).'" placeholder="Имя или email"><button>Найти</button><a class="button" href="/admin/users">Сбросить</a></form><div class="table-scroll"><table class="data-table"><thead><tr><th>ID</th><th>Пользователь</th><th>Записей</th><th>Отзывов</th><th>Роль</th><th></th></tr></thead><tbody>'.($rows?:'<tr><td colspan="6">Пользователей нет.</td></tr>').'</tbody></table></div>','users');
 }

 if($route==='/admin/reviews') {
  if($_SERVER['REQUEST_METHOD']==='POST'){checkCsrf();$id=(int)($_POST['id']??0);$action=$_POST['action']??'';if(!in_array($action,['publish','hide','delete'],true))throw new AppError(422,'Неизвестное действие.');if(!query('SELECT id FROM reviews WHERE id=?',[$id])->fetch())throw new AppError(404,'Отзыв не найден.');if($action==='delete')query('DELETE FROM reviews WHERE id=?',[$id]);else query('UPDATE reviews SET is_published=? WHERE id=?',[$action==='publish'?1:0,$id]);flash('Отзыв обновлён. Рейтинг учитывает только опубликованные отзывы.');redirect('/admin/reviews');}
  $q=trim($_GET['q']??'');$params=[];$sql='SELECT r.*,u.name customer,u.email,s.name service FROM reviews r JOIN users u ON u.id=r.user_id JOIN services s ON s.id=r.service_id';if($q!==''){$sql.=' WHERE u.name LIKE ? OR s.name LIKE ? OR r.text LIKE ?';$like='%'.$q.'%';$params=[$like,$like,$like];}$sql.=' ORDER BY r.id DESC';$items=query($sql,$params)->fetchAll();$rows='';
  foreach($items as $r)$rows.='<tr><td>#'.$r['id'].'</td><td><strong>'.esc($r['customer']).'</strong><br>'.esc($r['email']).'</td><td>'.esc($r['service']).'</td><td><span class="stars">'.str_repeat('★',(int)$r['rating']).str_repeat('☆',5-(int)$r['rating']).'</span></td><td class="description"><span class="status '.($r['is_published']?'completed':'cancelled').'">'.($r['is_published']?'Опубликован':'Скрыт').'</span><br>'.esc($r['text']).'<br><span class="meta">'.localDate($r['created_at']).'</span></td><td><div class="actions"><form method="post">'.csrf().'<input type="hidden" name="id" value="'.$r['id'].'"><input type="hidden" name="action" value="'.($r['is_published']?'hide':'publish').'"><button class="small">'.($r['is_published']?'Скрыть':'Опубликовать').'</button></form><form method="post" data-confirm="Удалить отзыв без возможности восстановления?">'.csrf().'<input type="hidden" name="id" value="'.$r['id'].'"><input type="hidden" name="action" value="delete"><button class="small danger">Удалить</button></form></div></td></tr>';
  adminPage('Отзывы','<form class="filters" method="get"><input aria-label="Поиск" name="q" value="'.esc($q).'" placeholder="Клиент, услуга или текст"><button>Найти</button><a class="button" href="/admin/reviews">Сбросить</a></form><div class="table-scroll"><table class="data-table"><thead><tr><th>ID</th><th>Клиент</th><th>Услуга</th><th>Оценка</th><th>Отзыв</th><th></th></tr></thead><tbody>'.($rows?:'<tr><td colspan="6">Отзывов нет.</td></tr>').'</tbody></table></div>','reviews');
 }

 // Promotions are implemented in Lab 5's promotions.php.
 if(str_starts_with($route,'/admin/promotions') && function_exists('promotionRoutes')) return false;
 throw new AppError(404,'Раздел админ-панели не найден.');
}
