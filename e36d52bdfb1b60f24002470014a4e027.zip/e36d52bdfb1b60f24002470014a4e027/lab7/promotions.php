<?php
function bestOffer(int $sid): ?array { return query('SELECT p.* FROM promotions p JOIN services s ON s.id=p.service_id WHERE p.sale_price<s.price AND s.is_active=1 AND service_id=? AND p.is_active=1 AND starts_at<=? AND ends_at>? ORDER BY sale_price ASC,ends_at ASC,id ASC LIMIT 1',[$sid,time(),time()])->fetch() ?: null; }
function activePromotions(): array { $now=time(); return query('SELECT p.*,s.name service_name,s.price FROM promotions p JOIN services s ON s.id=p.service_id WHERE s.is_active=1 AND p.is_active=1 AND p.starts_at<=? AND p.ends_at>? AND p.sale_price<s.price ORDER BY p.ends_at,p.id',[$now,$now])->fetchAll(); }
function promotionCard(array $p): string {
 $percent=(int)round(($p['price']-$p['sale_price'])*100/$p['price']); $image=is_file(__DIR__.'/assets/images/'.$p['image'])?$p['image']:service($p['service_id'])['image'];
 return '<article class="service-card promotion" id="promo-'.$p['id'].'"><img src="/assets/images/'.esc($image).'" alt="'.esc($p['service_name']).'" loading="lazy" width="640" height="427"><div class="card-body"><span class="promo-label '.$p['type'].'">'.TYPES[$p['type']].' · −'.$percent.'%</span><h3>'.esc($p['title']).'</h3><p>'.esc($p['description']).'</p><div><span class="old-price">'.money($p['price']).'</span><span class="price sale-price">'.money($p['sale_price']).'</span></div><div class="timer" data-end="'.$p['ends_at'].'">До '.localDate($p['ends_at']).' МСК</div><div class="period">'.localDate($p['starts_at']).' — '.localDate($p['ends_at']).' МСК</div><a class="button primary" href="/service?id='.$p['service_id'].'">Записаться на услугу</a></div></article>';
}
function promotionStatus(array $p): string { return !$p['is_active']?'Не опубликована':($p['starts_at']>time()?'Запланирована':($p['ends_at']<=time()?'Завершена':'Действует')); }
function promotionRoutes(string $route): bool {
 if($route==='/api/promotions') {
  $positions=activePromotions(); $services=query('SELECT * FROM services')->fetchAll(); $prices=[]; $amounts=[]; $labels=[]; $offerHtml=[];
  foreach($services as $s) { $p=bestOffer((int)$s['id']); $prices[$s['id']]=prices($s,$p); $amounts[$s['id']]=(int)($p['sale_price']??$s['price']); $labels[$s['id']]=$p?'<a class="promo-label '.$p['type'].'" href="/promotions#promo-'.$p['id'].'">'.TYPES[$p['type']].'</a>':''; $offerHtml[$s['id']]=$labels[$s['id']].($p?'<div class="timer" data-end="'.$p['ends_at'].'">До '.localDate($p['ends_at']).'</div>':''); }
  jsonResponse(['ok'=>true,'server_time'=>time(),'html'=>implode('',array_map('promotionCard',$positions)),'prices'=>$prices,'amounts'=>$amounts,'labels'=>$labels,'offers'=>$offerHtml]);
 }
 if($route==='/promotions') { $items=activePromotions(); render('Акции студии',page('Уход за авто с выгодой','<p>Акции дня, недели, месяца и короткие предложения. Скидки не суммируются: для услуги выбирается наименьшая действующая цена.</p><div class="cards" data-promotion-list>'.($items?implode('',array_map('promotionCard',$items)):'<p>Сейчас действующих предложений нет.</p>').'</div>')); }
 if($route==='/admin/promotions') {
  if(!currentUser()) redirect('/login'); needAdmin();
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf(); $id=(int)($_POST['id']??0); $action=$_POST['action']??'';
   if(!in_array($action,['publish','unpublish','delete'],true)) throw new AppError(422,'Неизвестное действие.');
   $item=query('SELECT * FROM promotions WHERE id=?',[$id])->fetch(); if(!$item) throw new AppError(404,'Акция не найдена.');
   db()->beginTransaction();
   try {
    query('SELECT id FROM services WHERE id=? FOR UPDATE',[$item['service_id']]);
    if($action==='publish'&&(int)$item['sale_price']>=(int)service($item['service_id'])['price'])throw new AppError(422,'Новая цена не ниже обычной. Сначала отредактируйте акцию.');
    if($action==='delete') query('DELETE FROM promotions WHERE id=?',[$id]);
    else query('UPDATE promotions SET is_active=? WHERE id=?',[$action==='publish'?1:0,$id]);
    db()->commit();
   } catch(Throwable $e) { if(db()->inTransaction()) db()->rollBack(); throw $e; }
   redirect('/admin/promotions');
  }
  $items=query('SELECT p.*,s.name service_name,s.price FROM promotions p JOIN services s ON s.id=p.service_id ORDER BY p.id DESC')->fetchAll(); $rows='';
  $search=mb_substr(trim($_GET['q']??''),0,100);$filterType=$_GET['type']??'';$state=$_GET['state']??'';
  $items=array_filter($items,fn($p)=>($search===''||mb_stripos($p['title'].' '.$p['service_name'],$search)!==false)&&($filterType===''||$p['type']===$filterType)&&($state===''||promotionStatus($p)===$state));
  $typeOptions='<option value="">Все типы</option>';foreach(TYPES as $k=>$v)$typeOptions.='<option value="'.$k.'" '.($filterType===$k?'selected':'').'>'.$v.'</option>';
  $stateOptions='<option value="">Все статусы</option>';foreach(['Действует','Запланирована','Завершена','Не опубликована'] as $v)$stateOptions.='<option '.($state===$v?'selected':'').'>'.$v.'</option>';
  $filters='<form method="get" class="filters"><input aria-label="Поиск акций" name="q" value="'.esc($search).'" placeholder="Название или услуга"><select name="type" aria-label="Тип акции">'.$typeOptions.'</select><select name="state" aria-label="Статус акции">'.$stateOptions.'</select><button>Найти</button><a class="button" href="/admin/promotions">Сбросить</a></form>';

  foreach($items as $p) {
   $publish=$p['is_active']?'unpublish':'publish';
   $actions='<a class="button small" href="/admin/promotions/edit?id='.$p['id'].'">Изменить</a><form method="post">'.csrf().'<input type="hidden" name="id" value="'.$p['id'].'"><input type="hidden" name="action" value="'.$publish.'"><button class="small">'.($p['is_active']?'Снять':'Опубликовать').'</button></form><form method="post" data-confirm="Удалить акцию? Цены прошлых записей сохранятся.">'.csrf().'<input type="hidden" name="id" value="'.$p['id'].'"><input type="hidden" name="action" value="delete"><button class="small danger">Удалить</button></form>';
   $rows.='<tr><td class="description"><strong>'.esc($p['title']).'</strong><br>'.esc($p['service_name']).'</td><td>'.TYPES[$p['type']].'</td><td>'.money($p['price']).'<br><span class="sale-price">'.money($p['sale_price']).'</span></td><td>'.localDate($p['starts_at']).'<br>'.localDate($p['ends_at']).'</td><td>'.promotionStatus($p).'</td><td><div class="actions">'.$actions.'</div></td></tr>';
  }
  adminPage('Акции студии',$filters.'<div class="admin-section-head"><div class="actions"><a class="button primary" href="/admin/promotions/edit">Создать акцию</a><a class="button" href="/promotions">Посмотреть на сайте</a></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>Предложение и услуга</th><th>Тип</th><th>Цены</th><th>Период МСК</th><th>Статус</th><th>Действия</th></tr></thead><tbody>'.($rows?:'<tr><td colspan="6">Акций пока нет.</td></tr>').'</tbody></table></div>','promotions');
 }
 if($route==='/admin/promotions/edit') {
  if(!currentUser()) redirect('/login'); needAdmin(); $id=(int)($_GET['id']??0); $old=$id?query('SELECT * FROM promotions WHERE id=?',[$id])->fetch():null;
  if($id && !$old) throw new AppError(404,'Акция не найдена.');
  $start=intdiv(time(),60)*60; $values=$old?:['service_id'=>1,'title'=>'','description'=>'','image'=>'wash.webp','type'=>'day','sale_price'=>200000,'starts_at'=>$start,'ends_at'=>$start+86400,'is_active'=>0]; $error='';
  $startText=inputDate($values['starts_at']); $endText=inputDate($values['ends_at']); $priceText=number_format($values['sale_price']/100,2,'.','');
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf(); $values=array_merge($values,$_POST); $values['is_active']=isset($_POST['is_active'])?1:0; $startText=$_POST['starts_at']??''; $endText=$_POST['ends_at']??''; $priceText=$_POST['sale_price']??'';
   try {
    $s=service($_POST['service_id']??0); if(!$s['is_active'])throw new AppError(422,'Услуга находится в архиве.'); $type=$_POST['type']??''; $limits=['minute'=>3540,'day'=>86400,'week'=>604800,'month'=>2678400];
    if(!isset($limits[$type])) throw new AppError(422,'Выберите допустимый тип акции.');
    $title=trim($_POST['title']??''); $text=trim($_POST['description']??'');
    if(mb_strlen($title)<3 || mb_strlen($title)>160 || mb_strlen($text)<3 || mb_strlen($text)>2000) throw new AppError(422,'Название от 3 до 160 символов, описание от 3 до 2000.');
    if(!preg_match('/^(\d{1,7})(?:[.,](\d{1,2}))?$/',$priceText,$m)) throw new AppError(422,'Введите цену в рублях с точностью до двух знаков после запятой.');
    $price=(int)$m[1]*100+(int)str_pad($m[2]??'',2,'0');
    if($price<=0 || $price>=(int)$s['price']) throw new AppError(422,'Цена акции должна быть больше нуля и ниже обычной цены.');
    $start=inputEpoch($startText); $end=inputEpoch($endText); $duration=$end-$start;
    if($duration<60 || $duration>$limits[$type]) throw new AppError(422,'Недопустимый срок: поминутная 1–59 минут, день до 24 часов, неделя до 7 суток, месяц до 31 суток.');
    $image=$_POST['image']??$s['image']; if(!in_array($image,['hero.webp','wash.webp','polish.webp','interior.webp'],true)) throw new AppError(422,'Выберите изображение из списка.');
    $active=isset($_POST['is_active'])?1:0; $values['is_active']=$active;
    db()->beginTransaction();
    try {
     $lockIds=$old?[(int)$old['service_id'],(int)$s['id']]:[(int)$s['id']]; sort($lockIds);
     foreach(array_unique($lockIds) as $sid) query('SELECT id FROM services WHERE id=? FOR UPDATE',[$sid]);
     $locked=service($s['id']); if($price>=(int)$locked['price']||!$locked['is_active'])throw new AppError(409,'Услуга изменилась. Проверьте актуальную цену и доступность.');
     $data=[$s['id'],$title,$text,$image,$type,$price,$start,$end,$active];
     if($id) { $data[]=$id; query('UPDATE promotions SET service_id=?,title=?,description=?,image=?,type=?,sale_price=?,starts_at=?,ends_at=?,is_active=? WHERE id=?',$data); }
     else query('INSERT INTO promotions(service_id,title,description,image,type,sale_price,starts_at,ends_at,is_active) VALUES(?,?,?,?,?,?,?,?,?)',$data);
     db()->commit(); redirect('/admin/promotions');
    } catch(Throwable $e) { if(db()->inTransaction()) db()->rollBack(); throw $e; }
   } catch(AppError $e) { $error=$e->getMessage(); }
  }
  $serviceOptions=''; foreach(query('SELECT id,name,price FROM services WHERE is_active=1')->fetchAll() as $s) $serviceOptions.='<option data-base-price="'.$s['price'].'" value="'.$s['id'].'" '.((int)$values['service_id']===(int)$s['id']?'selected':'').'>'.esc($s['name']).' · '.money($s['price']).'</option>';
  $types=''; foreach(TYPES as $key=>$label) $types.='<option value="'.$key.'" '.($values['type']===$key?'selected':'').'>'.$label.'</option>';
  $images=''; foreach(['wash.webp'=>'Мойка','polish.webp'=>'Полировка','interior.webp'=>'Салон','hero.webp'=>'Студия'] as $key=>$label) $images.='<option value="'.$key.'" '.($values['image']===$key?'selected':'').'>'.$label.'</option>';
  $fields='<div><label for="service_id">Услуга</label><select id="service_id" name="service_id">'.$serviceOptions.'</select></div>'.field('title','Название акции',$values['title'],'text','required minlength="3" maxlength="160"').'<div><label for="description">Описание</label><textarea id="description" name="description" minlength="3" maxlength="2000" required>'.esc($values['description']).'</textarea></div><div class="row"><div><label for="type">Тип акции</label><select name="type" id="type">'.$types.'</select></div>'.field('sale_price','Новая цена в рублях',$priceText,'text','required inputmode="decimal"').'</div><div class="row">'.field('starts_at','Начало по Москве',$startText,'datetime-local','required').field('ends_at','Окончание по Москве',$endText,'datetime-local','required').'</div><div class="row">'.field('minutes','Длительность в минутах',5,'number','min="1" max="59"').'<div><label>Поминутная акция</label><button type="button" id="calculate-end">Рассчитать окончание</button></div></div><div><label for="image">Фото предложения</label><select name="image" id="image">'.$images.'</select></div><div><label><input type="checkbox" name="is_active" value="1" '.(!empty($values['is_active'])?'checked':'').'> Опубликовать акцию</label></div>';
  $title=$id?'Редактировать акцию':'Создать акцию';
  adminPage($title,'<div class="split"><div class="admin-form-card">'.notice($error,true).'<form class="form-grid" method="post">'.csrf().$fields.'<div class="actions"><button class="primary">Сохранить</button><a class="button" href="/admin/promotions">Отмена</a></div></form></div><aside class="summary"><div class="eyebrow">ПРЕДПРОСМОТР ЦЕНЫ</div><h3>Выгода для клиента</h3><div id="promotion-preview" aria-live="polite"></div><hr><h3>Правила предложения</h3><p>Поминутная: 1–59 минут.<br>Дня: до 24 часов.<br>Недели: до 7 суток.<br>Месяца: до 31 суток.</p><p>Цена ниже обычной. Даты вводятся по Москве. Флаг публикации и текущий период проверяются отдельно.</p></aside></div>','promotions',$error?422:200);
 }
 return false;
}
