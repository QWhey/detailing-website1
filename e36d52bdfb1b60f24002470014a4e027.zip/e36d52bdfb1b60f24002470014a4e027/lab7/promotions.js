'use strict';
const PROMO_BASE = document.body.dataset.appBase || '';
let serverMs = Number(document.body.dataset.serverTime) * 1000;
let syncAt = performance.now();
let refreshing = false;
let lastRefresh = 0;
const nowMs = () => serverMs + performance.now() - syncAt;
async function refreshPromotions() {
  if (refreshing || performance.now() - lastRefresh < 1500) return;
  refreshing = true; lastRefresh = performance.now();
  try {
    const response = await fetch(PROMO_BASE + '/api/promotions', {cache: 'no-store'});
    if (!response.ok) return;
    const data = await response.json(); serverMs = data.server_time * 1000; syncAt = performance.now();
    document.querySelectorAll('[data-price]').forEach(node => {
      const markup = data.prices[node.dataset.price];
      if (markup) { const t = document.createElement('template'); t.innerHTML = markup; node.replaceWith(t.content.firstElementChild); }
    });
    const schemaNode = document.querySelector('#service-schema');
    const sid = new URLSearchParams(location.search).get('id');
    if (schemaNode && sid && data.amounts[sid] != null) { const schema = JSON.parse(schemaNode.textContent); schema.offers.price = (data.amounts[sid] / 100).toFixed(2); schemaNode.textContent = JSON.stringify(schema); }
    const list = document.querySelector('[data-promotion-list]');
    if(list){const template=document.createElement('template');template.innerHTML=data.html;const limit=Number(list.dataset.limit)||Infinity;list.replaceChildren(...[...template.content.children].slice(0,limit));if(!list.children.length)list.textContent='Сейчас действующих предложений нет.';}
    document.querySelectorAll('[data-promo-label]').forEach(n=>{n.innerHTML=data.labels[n.dataset.promoLabel]||'';});
    document.querySelectorAll('[data-service-offer]').forEach(n=>{n.innerHTML=data.offers[n.dataset.serviceOffer]||'';});
  } catch { /* Keep the latest server-rendered values when offline. */ }
  finally { refreshing = false; }
}
function tick() {
  document.querySelectorAll('[data-end]').forEach(node => {
    const seconds = Math.max(0, Math.ceil((Number(node.dataset.end) * 1000 - nowMs()) / 1000));
    if (!seconds) { node.textContent = 'Акция завершилась'; if (!node.dataset.expired) { node.dataset.expired = '1'; refreshPromotions(); } return; }
    const days = Math.floor(seconds / 86400);
    const h = String(Math.floor(seconds % 86400 / 3600)).padStart(2, '0');
    const m = String(Math.floor(seconds % 3600 / 60)).padStart(2, '0');
    const s = String(seconds % 60).padStart(2, '0');
    node.textContent = 'Осталось ' + (days ? days + ' дн. ' : '') + h + ':' + m + ':' + s;
  });
}
tick(); setInterval(tick, 1000); setInterval(refreshPromotions, 15000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshPromotions(); });
document.querySelector('#calculate-end')?.addEventListener('click', () => {
  const start = document.querySelector('#starts_at');
  const end = document.querySelector('#ends_at');
  const minutes = Number(document.querySelector('#minutes').value);
  if (!start.value || !Number.isInteger(minutes) || minutes < 1 || minutes > 59) return;
  const d = new Date(start.value + ':00+03:00'); d.setTime(d.getTime() + minutes * 60000 + 3 * 3600000);
  end.value = d.toISOString().slice(0,16);
});

function updatePromotionPreview(){
 const box=document.querySelector('#promotion-preview'), service=document.querySelector('#service_id'), input=document.querySelector('#sale_price');
 if(!box||!service||!input)return;
 const base=Number(service.selectedOptions[0]?.dataset.basePrice)/100, sale=Number(input.value.replace(',','.'));
 const format=n=>new Intl.NumberFormat('ru-RU',{style:'currency',currency:'RUB',maximumFractionDigits:2}).format(n);
 box.replaceChildren();const label=document.createElement('p');
 if(Number.isFinite(sale)&&sale>0&&sale<base){label.className='sale-note';label.textContent='Было '+format(base)+' → '+format(sale);const saving=document.createElement('strong');saving.textContent='Экономия '+format(base-sale)+' · −'+Math.round((base-sale)*100/base)+'%';box.append(label,saving);}
 else{label.textContent='Укажите положительную цену ниже '+format(base)+'.';box.append(label);}
}
document.querySelector('#service_id')?.addEventListener('change',updatePromotionPreview);
document.querySelector('#sale_price')?.addEventListener('input',updatePromotionPreview);
updatePromotionPreview();

document.addEventListener('apex:catalog-mode',()=>{lastRefresh=-2000;refreshPromotions();});
