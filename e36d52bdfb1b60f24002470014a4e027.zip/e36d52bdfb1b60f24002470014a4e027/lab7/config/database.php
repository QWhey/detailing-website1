<?php
// Beget: enter the host, database name, user and password from the hosting panel.
return [
    'host' => getenv('APEX_DB_HOST') ?: 'localhost',
    'port' => getenv('APEX_DB_PORT') ?: '3307',
    'name' => getenv('APEX_DB_NAME') ?: 'o92999hi_akim',
    'user' => getenv('APEX_DB_USER') ?: 'o92999hi_akim',
    'password' => getenv('APEX_DB_PASSWORD') ?: '04072007aA',
];
