<?php
declare(strict_types=1);
ini_set('session.use_strict_mode','1');
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off']);
session_start();
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
const TYPES = ['minute'=>'Поминутная акция','day'=>'Акция дня','week'=>'Акция недели','month'=>'Акция месяца'];
const STATUS = ['new'=>'Ожидает визита','completed'=>'Выполнено','cancelled'=>'Отменено'];
const MOSCOW = 'Europe/Moscow';
function db(): PDO {
 static $pdo;
 if (!$pdo) {
  $c=require __DIR__.'/database.php';
  $pdo=new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4",$c['user'],$c['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
 }
 return $pdo;
}
function query(string $sql,array $params=[]): PDOStatement { $q=db()->prepare($sql); $q->execute($params); return $q; }
function esc($x): string { return htmlspecialchars((string)$x,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function money($kopecks): string { $n=(int)$kopecks; return number_format(intdiv($n,100),0,',',' ').($n%100 ? ','.str_pad((string)($n%100),2,'0',STR_PAD_LEFT):'').' ₽'; }
function localDate($epoch): string { return (new DateTimeImmutable('@'.$epoch))->setTimezone(new DateTimeZone(MOSCOW))->format('d.m.Y H:i'); }
function inputDate($epoch): string { return (new DateTimeImmutable('@'.$epoch))->setTimezone(new DateTimeZone(MOSCOW))->format('Y-m-d\TH:i'); }
function inputEpoch(string $text): int {
 $d=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$text,new DateTimeZone(MOSCOW));
 if (!$d || $d->format('Y-m-d\TH:i')!==$text) throw new AppError(422,'Введите корректные дату и время.');
 return $d->getTimestamp();
}
function csrf(): string { return '<input type="hidden" name="csrf" value="'.esc($_SESSION['csrf']).'">'; }
function checkCsrf(): void { if (!hash_equals($_SESSION['csrf'],(string)($_POST['csrf']??''))) throw new AppError(419,'Защитный токен устарел. Обновите страницу.'); }
function postOnly(): void { if ($_SERVER['REQUEST_METHOD']!=='POST') throw new AppError(405,'Для изменения данных нужен POST-запрос.'); }
function currentUser(): ?array { return empty($_SESSION['uid']) ? null : (query('SELECT id,name,email,role FROM users WHERE id=?',[$_SESSION['uid']])->fetch() ?: null); }
function needUser(): array { $u=currentUser(); if (!$u) throw new AppError(401,'Войдите в аккаунт, чтобы продолжить.'); return $u; }
function needAdmin(): array { $u=needUser(); if($u['role']!=='admin') throw new AppError(403,'Раздел доступен только администратору.'); return $u; }
function appBase(): string {
 $dir=str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']??'/'));
 return $dir==='/' || $dir==='.' ? '' : rtrim($dir,'/');
}
function appUrl(string $path='/'): string {
 if($path==='' || $path==='/') return appBase().'/';
 if(preg_match('~^(?:https?:)?//~i',$path)) return $path;
 return appBase().'/'.ltrim($path,'/');
}
function requestRoute(): string {
 $path=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH) ?: '/';
 $base=appBase();
 if($base!=='' && ($path===$base || str_starts_with($path,$base.'/'))) $path=substr($path,strlen($base)) ?: '/';
 $aliases=['/catalog_native.php'=>'/catalog/native','/catalog_io.php'=>'/catalog/io','/catalog_skeleton.php'=>'/catalog/skeleton','/api/products.php'=>'/api/services','/admin/product_seo.php'=>'/admin/services/seo','/admin/products.php'=>'/admin/services'];
 if(isset($aliases[$path]))return $aliases[$path];
 if($path==='/index.php') return '/';
 return $path;
}
function prefixHtmlPaths(string $html): string {
 $base=appBase();if($base==='')return $html;
 return preg_replace_callback('~(?<![-\w])(href|src|action)=(["\'])(/(?!/)[^"\']*)\2~i',function($m)use($base){$path=$m[3];return $m[1].'='.$m[2].(str_starts_with($path,$base.'/')?$path:$base.$path).$m[2];},$html)??$html;
}
function redirect(string $url): never { header('Location: '.appUrl($url),true,303); exit; }
function jsonResponse(array $data,int $status=200): never {
 array_walk_recursive($data,function(&$v){ if(is_string($v) && str_contains($v,'="/')) $v=prefixHtmlPaths($v); });
 http_response_code($status); header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff'); header('Content-Type: application/json; charset=utf-8'); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
function service($id): array { if(!ctype_digit((string)$id)||(int)$id<1)throw new AppError(404,'Услуга не найдена.'); $s=query('SELECT * FROM services WHERE id=?',[(int)$id])->fetch(); if(!$s) throw new AppError(404,'Услуга не найдена.'); return $s; }
function hasVisit(int $uid,int $sid): bool { return (bool)query("SELECT 1 FROM bookings WHERE user_id=? AND service_id=? AND status='completed' LIMIT 1",[$uid,$sid])->fetchColumn(); }
function reviews(int $sid): array { return query('SELECT r.*,u.name FROM reviews r JOIN users u ON u.id=r.user_id WHERE service_id=? AND r.is_published=1 ORDER BY r.created_at DESC,r.id DESC',[$sid])->fetchAll(); }
function offer(int $sid): ?array { return function_exists('bestOffer') ? bestOffer($sid) : null; }
class AppError extends RuntimeException { public int $status; public function __construct(int $status,string $message) { parent::__construct($message); $this->status=$status; } }

function absoluteUrl(string $path): string { return origin().appUrl($path); }
