<?php
if(PHP_SAPI!=='cli') { http_response_code(404); exit; }
require dirname(__DIR__).'/config/app.php';
if($argc!==3 || !filter_var($argv[1],FILTER_VALIDATE_EMAIL) || (strlen($argv[2])<8 || strlen($argv[2])>72)) { fwrite(STDERR,"Usage: php tools/create_admin.php email password (8-72 bytes)\n"); exit(1); }
query('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash),role=VALUES(role)',['Администратор студии',strtolower($argv[1]),password_hash($argv[2],PASSWORD_DEFAULT),'admin']);
echo "Administrator updated.\n";
