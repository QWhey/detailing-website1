<?php
// Lab 7 extends the existing services table and admin session.
function settings(): array {
 static $values;
 if($values===null){$values=[];foreach(query('SELECT `key`,`value` FROM settings')->fetchAll() as $row)$values[$row['key']]=$row['value'];}
 return $values;
}
function setting(string $key,string $default=''): string { return settings()[$key]??$default; }
function assetPath(string $path): string {
 $file=__DIR__.'/'.$path;$version=is_file($file)?substr(hash_file('sha256',$file),0,10):'1';
 return '/'.ltrim($path,'/').'?v='.$version;
}
function brandHtml(): string {
 return '<img class="brand-logo" src="'.assetPath(setting('site_logo','/assets/brand/apex-detailing-logo.svg')).'" alt="'.esc(setting('site_logo_alt','Apex Detailing — логотип студии')).'" width="160" height="48" decoding="async">';
}
function validateLocalImage(string $path,string $extension=''): string {
 if(!preg_match('~^/assets/images/[a-z0-9][a-z0-9_-]*\.(?:webp|jpe?g|png)$~D',$path))throw new AppError(422,'Используйте локальный путь /assets/images/имя.webp или .jpg.');
 $real=realpath(__DIR__.$path);$folder=realpath(__DIR__.'/assets/images').DIRECTORY_SEPARATOR;
 if(!$real||!str_starts_with($real,$folder)||!is_file($real))throw new AppError(422,'Файл изображения не найден. Сначала загрузите его в assets/images.');
 if($extension!==''&&!preg_match('~\.'.$extension.'$~i',$real))throw new AppError(422,'Неверный формат изображения.');
 if(!getimagesize($real))throw new AppError(422,'Файл не является поддерживаемым изображением.');
 return $path;
}
function imageData(array $s): array {
 $webp=$s['image_webp']?:'/assets/images/'.$s['image'];$jpeg=$s['image_jpeg']?:$webp;
 if(!is_file(__DIR__.$webp))$webp='/assets/images/'.$s['image'];
 if(!is_file(__DIR__.$jpeg))$jpeg=$webp;
 $dimensions=getimagesize(__DIR__.$webp)?:[1280,853];
 return ['webp'=>$webp,'jpeg'=>$jpeg,'alt'=>$s['image_alt']?:$s['name'].' — уход за автомобилем в Apex Detailing','title'=>$s['image_title']?:$s['name'],'width'=>(int)($s['image_width']?:$dimensions[0]),'height'=>(int)($s['image_height']?:$dimensions[1])];
}
function imageSrcset(string $path): string {
 $info=pathinfo($path);$items=[];
 foreach([480,800] as $width){$candidate=$info['dirname'].'/'.$info['filename'].'-'.$width.'.'.$info['extension'];if(is_file(__DIR__.$candidate))$items[]=appUrl(assetPath($candidate)).' '.$width.'w';}
 $size=getimagesize(__DIR__.$path);$items[]=appUrl(assetPath($path)).' '.($size[0]??1280).'w';return implode(', ',$items);
}
function imageMarkup(array $s,string $context='card',string $mode='native'): string {
 $i=imageData($s);$sizes=$context==='detail'?'(max-width: 900px) 100vw, 620px':'(max-width: 650px) 100vw, (max-width: 900px) 50vw, 400px';
 $attributes=' alt="'.esc($i['alt']).'" title="'.esc($i['title']).'" width="'.$i['width'].'" height="'.$i['height'].'" decoding="async"';
 $src=appUrl(assetPath($i['jpeg']));$srcset=imageSrcset($i['jpeg']);$webp=imageSrcset($i['webp']);
 if($mode!=='native'){
  $placeholder='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%221%22 height=%221%22/%3E';
  return '<picture class="lazy-picture" data-load-state="pending"><source type="image/webp" data-srcset="'.esc($webp).'" sizes="'.esc($sizes).'"><img class="lazy-image" src="'.$placeholder.'" data-src="'.esc($src).'" data-srcset="'.esc($srcset).'" sizes="'.esc($sizes).'"'.$attributes.'><span class="image-error" hidden>Изображение недоступно</span></picture>';
 }
 $loading=$context==='detail'?'fetchpriority="high" loading="eager"':'loading="lazy"';
 return '<picture><source type="image/webp" srcset="'.esc($webp).'" sizes="'.esc($sizes).'"><img src="'.esc($src).'" srcset="'.esc($srcset).'" sizes="'.esc($sizes).'" '.$loading.$attributes.'></picture>';
}
function getCatalogServices(int $limit=20,int $offset=0): array {
 $limit=max(1,min(60,$limit));$offset=max(0,min(10000,$offset));$now=time();
 // Reviews are aggregated before joining one cheapest promotion: no multiplication of rows.
 $sql='SELECT s.*,COALESCE(r.reviews_count,0) reviews_count,r.avg_rating,p.id promo_id,p.title promo_title,p.type promo_type,p.sale_price,p.ends_at promo_ends_at FROM services s LEFT JOIN (SELECT service_id,COUNT(*) reviews_count,ROUND(AVG(rating),1) avg_rating FROM reviews WHERE is_published=1 GROUP BY service_id) r ON r.service_id=s.id LEFT JOIN promotions p ON p.id=(SELECT pr.id FROM promotions pr WHERE pr.service_id=s.id AND pr.is_active=1 AND pr.starts_at<=? AND pr.ends_at>? AND pr.sale_price<s.price ORDER BY pr.sale_price,pr.ends_at,pr.id LIMIT 1) WHERE s.is_active=1 ORDER BY s.id LIMIT '.$limit.' OFFSET '.$offset;
 return query($sql,[$now,$now])->fetchAll();
}
function lazyCard(array $s,string $mode): string {
 $p=empty($s['promo_id'])?null:['id'=>$s['promo_id'],'type'=>$s['promo_type'],'sale_price'=>$s['sale_price']];
 $rating=$s['reviews_count']?'<span class="stars">★</span> '.number_format((float)$s['avg_rating'],1,',','').' · отзывов: '.(int)$s['reviews_count']:'Пока нет отзывов';
 return '<article class="service-card lazy-card" data-service-id="'.$s['id'].'"><a class="card-image '.($mode==='skeleton'?'with-skeleton':'').'" href="/service?id='.$s['id'].'">'.($mode==='skeleton'?'<span class="skeleton" aria-hidden="true"></span>':'').imageMarkup($s,'card',$mode).($mode!=='native'?'<noscript>'.imageMarkup($s,'card','native').'</noscript>':'').'</a><div class="card-body"><div class="card-meta"><span>'.esc($s['category']).'</span><span>'.$s['duration'].' мин.</span></div><span data-promo-label="'.$s['id'].'">'.($p?'<a class="promo-label '.$p['type'].'" href="/promotions#promo-'.$p['id'].'">'.TYPES[$p['type']].'</a>':'').'</span><h3><a href="/service?id='.$s['id'].'">'.esc($s['name']).'</a></h3><p>'.esc($s['description']).'</p><div class="card-rating">'.$rating.'</div><div class="card-bottom">'.prices($s,$p).'<a class="button small" href="/service?id='.$s['id'].'">Подробнее ↗</a></div></div></article>';
}
function catalogApi(): never {
 if($_SERVER['REQUEST_METHOD']!=='GET')throw new AppError(405,'Для каталога используйте GET.');
 foreach(['limit','offset'] as $key)if(isset($_GET[$key])&&!preg_match('/^\d{1,5}$/D',(string)$_GET[$key]))throw new AppError(422,'limit и offset должны быть неотрицательными целыми числами.');
 $limit=max(1,min(60,(int)($_GET['limit']??20)));$offset=min(10000,(int)($_GET['offset']??0));$rows=getCatalogServices($limit,$offset);$items=[];
 foreach($rows as $s){$i=imageData($s);$price=(int)($s['sale_price']??$s['price']);$items[]=['id'=>(int)$s['id'],'title'=>$s['name'],'description'=>$s['description'],'category'=>$s['category'],'duration'=>(int)$s['duration'],'base_price'=>(int)$s['price'],'price'=>$price,'price_rubles'=>number_format($price/100,2,'.',''),'currency'=>'RUB','image_url'=>appUrl(assetPath($i['webp'])),'image_jpeg'=>appUrl(assetPath($i['jpeg'])),'image_srcset'=>imageSrcset($i['webp']),'alt_text'=>$i['alt'],'image_title'=>$i['title'],'width'=>$i['width'],'height'=>$i['height'],'avg_rating'=>$s['avg_rating']===null?null:(float)$s['avg_rating'],'reviews_count'=>(int)$s['reviews_count'],'promo_type'=>$s['promo_type'],'promo_title'=>$s['promo_title'],'promo_id'=>$s['promo_id']?(int)$s['promo_id']:null,'promo_discount'=>$s['sale_price']?(int)round(($s['price']-$s['sale_price'])*100/$s['price']):0,'url'=>appUrl('/service?id='.$s['id'])];}
 jsonResponse(['ok'=>true,'count'=>count($items),'total'=>(int)query('SELECT COUNT(*) FROM services WHERE is_active=1')->fetchColumn(),'limit'=>$limit,'offset'=>$offset,'server_time'=>time(),'items'=>$items]);
}
function seoRoutes(string $route): bool {
 if($route==='/api/services')catalogApi();
 if($route==='/sitemap.xml'){
  header('Content-Type: application/xml; charset=utf-8');$paths=['/','/services','/about','/contacts','/promotions'];foreach(query('SELECT id FROM services WHERE is_active=1')->fetchAll() as $s)$paths[]='/service?id='.$s['id'];echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';foreach($paths as $x)echo '<url><loc>'.esc(absoluteUrl($x)).'</loc></url>';echo '</urlset>';exit;
 }
 if(in_array($route,['/catalog','/catalog/native','/catalog/io','/catalog/skeleton'],true)){
  $mode=$route==='/catalog'?'native':basename($route);$labels=['native'=>'Нативная загрузка','io'=>'Intersection Observer','skeleton'=>'Skeleton и Observer'];$rows=getCatalogServices(60,0);
  $body=fragment(function()use($mode,$labels,$rows){?>
   <div class="page-intro"><div class="eyebrow">КАТАЛОГ СТУДИИ</div><h1>Услуги и цены</h1><p>Выберите уход за автомобилем и сравните стоимость. Актуальные отзывы и акции сохранены во всех вариантах каталога.</p></div><nav class="loading-tabs" aria-label="Вариант загрузки изображений" data-loading-switcher><?php foreach($labels as $key=>$label):?><a data-loading-mode="<?=$key?>" <?=$key===$mode?'aria-current="page"':''?> class="<?=$key===$mode?'active':''?>" href="/catalog/<?=$key?>"><?=$label?></a><?php endforeach;?></nav><div class="loading-status"><div><strong data-mode-name><?=$labels[$mode]?></strong><p data-mode-description>Выберите способ загрузки изображений. Карточки и цены сохранятся.</p><p class="help" data-image-progress role="status" aria-live="polite"></p></div><button id="reload-images" class="small" type="button">Повторить загрузку</button></div><div class="catalog-result"><span>Услуг: <?=count($rows)?></span><a href="/services">Поиск и фильтры →</a></div><h2 class="sr-only">Каталог услуг</h2><div class="cards lazy-catalog" data-lazy-mode="<?=$mode?>"><?=implode('',array_map(fn($s)=>lazyCard($s,$mode),$rows))?></div><?php foreach($labels as $key=>$label):?><template data-mode-template="<?=$key?>"><?=implode('',array_map(fn($s)=>lazyCard($s,$key),$rows))?></template><?php endforeach;?><noscript><style>.loading-status{display:none}.lazy-picture,.skeleton{display:none!important}</style><p>Изображения доступны в <a href="/catalog/native">нативном каталоге</a>. Карточки, цены и ссылки работают без JavaScript.</p></noscript>
  <?php });render('Услуги — '.$labels[$mode],'<div class="wrap page">'.$body.'</div>');
 }
 if($route==='/admin/services/seo'){
  if(!currentUser())redirect('/admin/login');needAdmin();$s=service($_GET['id']??0);$error='';$values=$s;
  if($_SERVER['REQUEST_METHOD']==='POST'){
   checkCsrf();$values=array_merge($s,$_POST);
   try{
    $alt=trim($_POST['image_alt']??'');$title=trim($_POST['image_title']??'');if(mb_strlen($alt)<3||mb_strlen($alt)>255||mb_strlen($title)>255)throw new AppError(422,'Alt: от 3 до 255 символов, title: до 255 символов.');
    $webp=validateLocalImage(trim($_POST['image_webp']??''),'webp');$jpeg=validateLocalImage(trim($_POST['image_jpeg']??''),'jpe?g');$w=(int)($_POST['image_width']??0);$h=(int)($_POST['image_height']??0);$actual=getimagesize(__DIR__.$webp);$fallback=getimagesize(__DIR__.$jpeg);
    if($w<1||$w>10000||$h<1||$h>10000||$actual[0]!==$w||$actual[1]!==$h||$fallback[0]!==$w||$fallback[1]!==$h)throw new AppError(422,'Ширина и высота должны совпадать с фактическими размерами обоих файлов.');
    query('UPDATE services SET image_alt=?,image_title=?,image_webp=?,image_jpeg=?,image_width=?,image_height=? WHERE id=?',[$alt,$title,$webp,$jpeg,$w,$h,$s['id']]);flash('SEO изображения сохранено. Проверьте карточку услуги.');redirect('/admin/services/seo?id='.$s['id']);
   }catch(AppError $e){$error=$e->getMessage();}
  }
  $body=fragment(function()use($s,$values,$error){?>
   <div class="split"><div class="admin-form-card"><?=notice($error,true)?><form method="post" class="form-grid"><?=csrf()?><?=field('image_alt','Alt — описание фотографии',$values['image_alt'],'text','required minlength="3" maxlength="255"')?><p class="help">Опишите видимый объект и действие. Не перечисляйте поисковые запросы.</p><?=field('image_title','Title — короткий заголовок',$values['image_title'],'text','maxlength="255"')?><?=field('image_webp','Путь к WebP',$values['image_webp'],'text','required maxlength="500"')?><?=field('image_jpeg','Путь к JPEG',$values['image_jpeg'],'text','required maxlength="500"')?><div class="row"><?=field('image_width','Ширина, px',$values['image_width'],'number','required min="1" max="10000"')?><?=field('image_height','Высота, px',$values['image_height'],'number','required min="1" max="10000"')?></div><div class="actions"><button class="primary">Сохранить SEO</button><a class="button" href="/admin/services">К услугам</a></div></form></div><aside class="summary"><h2><?=esc($s['name'])?></h2><?=imageMarkup($s,'detail')?><p class="help">Предпросмотр сохранённых данных. Размеры проверяются по файлу. Существующие WebP и JPEG находятся в assets/images.</p><a class="button small" href="/service?id=<?=$s['id']?>">Открыть на сайте ↗</a></aside></div>
  <?php });adminPage('SEO изображения',$body,'services',$error?422:200);
 }
 if($route==='/admin/settings'){
  if(!currentUser())redirect('/admin/login');needAdmin();$error='';$v=settings();
  if($_SERVER['REQUEST_METHOD']==='POST'){
   checkCsrf();$v=array_merge($v,$_POST);
   try{foreach(['site_name'=>[2,120],'site_description'=>[10,300],'site_logo_alt'=>[3,255]] as $key=>$range){$text=trim($_POST[$key]??'');if(mb_strlen($text)<$range[0]||mb_strlen($text)>$range[1])throw new AppError(422,'Проверьте длину названия, описания и alt логотипа.');$v[$key]=$text;}
    db()->beginTransaction();try{foreach(['site_name','site_description','site_logo_alt'] as $key)query('INSERT INTO settings(`key`,`value`) VALUES(?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)',[$key,$v[$key]]);db()->commit();}catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}flash('Настройки студии сохранены.');redirect('/admin/settings');
   }catch(AppError $e){$error=$e->getMessage();}
  }
  $form=notice($error,true).'<form class="form-grid" method="post">'.csrf().field('site_name','Название студии',$v['site_name'],'text','required maxlength="120"').'<div><label for="site_description">Описание сайта</label><textarea id="site_description" name="site_description" required minlength="10" maxlength="300">'.esc($v['site_description']).'</textarea></div>'.field('site_logo_alt','Alt логотипа',$v['site_logo_alt'],'text','required maxlength="255"').'<button class="primary">Сохранить настройки</button></form>';
  adminPage('Настройки студии','<div class="split"><div class="admin-form-card">'.$form.'</div><aside class="summary"><h3>SVG логотип</h3>'.brandHtml().'<p>Файл: '.esc($v['site_logo']).'</p><p>Настройки используются в шапке, метатегах и Organization JSON-LD.</p></aside></div>','settings',$error?422:200);
 }
 return false;
}
