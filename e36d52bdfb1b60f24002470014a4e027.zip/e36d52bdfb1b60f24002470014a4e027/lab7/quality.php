<?php
// Shared improvements for Labs 4, 5 and 7. Existing data is preserved.
function fragment(callable $fn): string { ob_start(); $fn(); return ob_get_clean(); }
function flash(string $message): void { $_SESSION['flash']=$message; }
function takeFlash(): string { $text=$_SESSION['flash']??''; unset($_SESSION['flash']); return notice($text); }
function safeNext($path): string {
 $path=(string)$path;
 return preg_match('~^/(?:booking\?id=\d+|service\?id=\d+(?:\#reviews)?|account|admin(?:/[a-z/]+)?)$~D',$path) ? $path : '/account';
}
function catalogueRows(): array {
 $promo=function_exists('bestOffer');
 $extra=$promo?",(SELECT p.sale_price FROM promotions p WHERE p.service_id=s.id AND p.is_active=1 AND p.starts_at<=? AND p.ends_at>? AND p.sale_price<s.price ORDER BY p.sale_price,p.ends_at,p.id LIMIT 1) offer_price":',NULL offer_price';
 $now=time();
 return query('SELECT s.*,COALESCE(r.reviews_count,0) reviews_count,r.avg_rating'.$extra.' FROM services s LEFT JOIN (SELECT service_id,COUNT(*) reviews_count,ROUND(AVG(rating),1) avg_rating FROM reviews WHERE is_published=1 GROUP BY service_id) r ON r.service_id=s.id WHERE s.is_active=1 ORDER BY s.id',$promo?[$now,$now]:[])->fetchAll();
}
function faqBlock(): string {
 return '<div class="faq-list"><details><summary>Как выбрать услугу?</summary><p>Для регулярного ухода подойдёт детейлинг-мойка. Полировка помогает убрать мелкие дефекты, химчистка — очистить салон. Состав и длительность каждой работы указаны в карточке.</p></details><details><summary>Когда подтверждается запись?</summary><p>Вы выбираете желаемую дату и время. Заявка появится в личном кабинете, а администратор согласует время визита с вами по указанному телефону.</p></details><details><summary>Когда можно оставить отзыв?</summary><p>После выполнения работы администратор изменит статус визита. В личном кабинете появится ссылка на отзыв именно о полученной услуге.</p></details><details><summary>Можно отменить запись?</summary><p>Да. Будущую заявку со статусом «Ожидает визита» можно отменить в личном кабинете. История и согласованная цена сохранятся.</p></details></div>';
}
function qualityRoutes(string $route): bool {
 if($route==='/account/cancel') {
  postOnly();$u=needUser();checkCsrf();$id=(int)($_POST['id']??0);
  $q=query("UPDATE bookings SET status='cancelled' WHERE id=? AND user_id=? AND status='new' AND visit_at>?",[$id,$u['id'],time()]);
  if(!$q->rowCount())throw new AppError(409,'Эту заявку нельзя отменить: проверьте владельца, дату и статус.');
  flash('Запись отменена. История визита сохранена.');redirect('/account');
 }
 if($route==='/account/profile') {
  if(!currentUser())redirect('/login?next=/account');$u=needUser();$error='';
  if($_SERVER['REQUEST_METHOD']==='POST') {
   checkCsrf();$name=trim($_POST['name']??'');$email=mb_strtolower(trim($_POST['email']??''));$new=(string)($_POST['new_password']??'');
   try {
    if(mb_strlen($name)<2||mb_strlen($name)>80)throw new AppError(422,'Имя должно содержать от 2 до 80 символов.');
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>160)throw new AppError(422,'Введите корректный email.');
    $hash=query('SELECT password_hash FROM users WHERE id=?',[$u['id']])->fetchColumn();
    if(($email!==$u['email']||$new!=='')&&!password_verify((string)($_POST['current_password']??''),$hash))throw new AppError(422,'Для изменения email или пароля укажите действующий пароль.');
    if($new!==''&&(strlen($new)<8||strlen($new)>72||$new!==($_POST['confirm_password']??'')))throw new AppError(422,'Новый пароль: от 8 до 72 байт. Повтор пароля должен совпадать.');
    if(query('SELECT id FROM users WHERE email=? AND id<>?',[$email,$u['id']])->fetch())throw new AppError(422,'Этот email уже используется.');
    query('UPDATE users SET name=?,email=?,password_hash=? WHERE id=?',[$name,$email,$new!==''?password_hash($new,PASSWORD_DEFAULT):$hash,$u['id']]);
    if($new!=='')session_regenerate_id(true);flash('Данные профиля сохранены.');redirect('/account');
   }catch(AppError $e){$error=$e->getMessage();}
  }
  $body=fragment(function()use($u,$error){?>
   <div class="profile-layout"><aside class="summary"><div class="eyebrow">ЛИЧНЫЙ КАБИНЕТ</div><h2>Ваш профиль</h2><p>Обновите имя, почту или пароль. История записей останется в аккаунте.</p><a class="button" href="/account">К моим записям</a></aside><div class="profile-form"><?=notice($error,true)?><form method="post" class="form-grid"><?=csrf()?><?=field('name','Имя',$_POST['name']??$u['name'],'text','required maxlength="80" autocomplete="name"')?><?=field('email','Email',$_POST['email']??$u['email'],'email','required maxlength="160" autocomplete="email"')?><hr><h3>Изменить пароль</h3><p class="help">Оставьте новые поля пустыми, если пароль менять не нужно.</p><?=field('current_password','Текущий пароль','','password','autocomplete="current-password" maxlength="128"')?><?=field('new_password','Новый пароль','','password','autocomplete="new-password" minlength="8" maxlength="72"')?><?=field('confirm_password','Повторите новый пароль','','password','autocomplete="new-password" maxlength="72"')?><button class="primary">Сохранить профиль</button></form></div></div>
  <?php });render('Настройки профиля',page('Настройки профиля',$body),$error?422:200);
 }
 if($route==='/account') {
  if(!currentUser())redirect('/login?next=/account');$u=needUser();
  $rows=query('SELECT b.*,s.name,s.image,r.id review_id FROM bookings b JOIN services s ON s.id=b.service_id LEFT JOIN reviews r ON r.user_id=b.user_id AND r.service_id=b.service_id WHERE b.user_id=? ORDER BY b.id DESC',[$u['id']])->fetchAll();
  $filter=$_GET['status']??'';$counts=array_count_values(array_column($rows,'status'));
  $body=fragment(function()use($rows,$u,$filter,$counts){?>
   <?=takeFlash()?><?=isset($_GET['saved'])?notice('Заявка сохранена. Время визита согласует администратор.'):''?>
   <div class="account-top"><div><div class="eyebrow">ВАШ АВТОМОБИЛЬ В ФОКУСЕ</div><h2>Здравствуйте, <?=esc($u['name'])?></h2><p><?=esc($u['email'])?></p></div><div class="actions"><a class="button" href="/account/profile">Настройки профиля</a><?php if($u['role']==='admin'):?><a class="button" href="/admin">Админ-панель</a><?php endif;?><a class="button primary" href="/services">Новая запись</a></div></div>
   <nav class="account-tabs" aria-label="Фильтр визитов"><a class="<?=$filter===''?'active':''?>" href="/account">Все визиты <span><?=count($rows)?></span></a><?php foreach(STATUS as $key=>$label):?><a class="<?=$filter===$key?'active':''?>" href="/account?status=<?=$key?>"><?=$label?> <span><?=$counts[$key]??0?></span></a><?php endforeach;?></nav>
   <div class="booking-list"><?php $visible=0;foreach($rows as $b):if($filter!==''&&$filter!==$b['status'])continue;$visible++;?>
    <article class="booking-row"><img class="booking-thumb" src="/assets/images/<?=esc($b['image'])?>" alt="<?=esc($b['name'])?>" loading="lazy" width="160" height="110"><div><div class="meta">ЗАПИСЬ №<?=$b['id']?> · <?=localDate($b['created_at'])?></div><h3><a href="/service?id=<?=$b['service_id']?>"><?=esc($b['name'])?></a></h3><span class="status <?=$b['status']?>"><?=STATUS[$b['status']]?></span><p><?=esc($b['car'])?> · <?=esc($b['phone'])?></p><p>Визит: <strong><?=localDate($b['visit_at'])?> МСК</strong></p><?php if(!empty($b['promotion_title'])):?><p class="sale-note"><?=esc($b['promotion_title'])?><?php if(!empty($b['base_price'])):?> · экономия <?=money($b['base_price']-$b['price'])?><?php endif;?></p><?php endif;?></div><div class="booking-price"><div class="price"><?=money($b['price'])?></div><p class="help">Цена при оформлении</p><?php if($b['status']==='completed'):?><a class="button small" href="/service?id=<?=$b['service_id']?>#reviews"><?=$b['review_id']?'Изменить отзыв':'Оставить отзыв'?></a><?php elseif($b['status']==='new'&&$b['visit_at']>time()):?><form method="post" action="/account/cancel" data-confirm="Отменить запись? История визита сохранится."><?=csrf()?><input type="hidden" name="id" value="<?=$b['id']?>"><button class="small danger">Отменить запись</button></form><?php endif;?></div></article>
   <?php endforeach;if(!$visible):?><div class="empty-state"><h3>Здесь пока нет визитов</h3><p>Выберите услугу и удобное время. Запись появится в этом разделе.</p><a class="button primary" href="/services">Выбрать услугу</a></div><?php endif;?></div>
  <?php });render('Личный кабинет',page('Мои записи',$body));
 }
 if($route==='/services') {
  $term=mb_substr(trim($_GET['q']??''),0,100);$category=(string)($_GET['category']??'');$sort=(string)($_GET['sort']??'popular');$rows=catalogueRows();
  $categories=array_unique(array_column($rows,'category'));sort($categories);
  $rows=array_values(array_filter($rows,fn($s)=>mb_stripos($s['name'].' '.$s['description'],$term)!==false&&($category===''||$category===$s['category'])));
  usort($rows,match($sort){'price_asc'=>fn($a,$b)=>($a['offer_price']??$a['price'])<=>($b['offer_price']??$b['price']),'price_desc'=>fn($a,$b)=>($b['offer_price']??$b['price'])<=>($a['offer_price']??$a['price']),'duration'=>fn($a,$b)=>$a['duration']<=>$b['duration'],default=>fn($a,$b)=>($b['reviews_count']<=>$a['reviews_count'])?:($a['id']<=>$b['id'])});
  $body=fragment(function()use($rows,$term,$category,$categories,$sort){?>
   <div class="page-intro"><div class="eyebrow">КУЗОВ · САЛОН · ЗАЩИТА</div><h1>Услуги и цены</h1><p>Подберите уход под задачи вашего автомобиля. Состав работ, длительность и отзывы — в каждой карточке.</p></div>
   <form class="filters catalog-filters" method="get"><div><label for="search-services">Поиск</label><input id="search-services" name="q" value="<?=esc($term)?>" placeholder="Название или задача" maxlength="100"></div><div><label for="category">Направление</label><select id="category" name="category"><option value="">Все направления</option><?php foreach($categories as $c):?><option value="<?=esc($c)?>" <?=$category===$c?'selected':''?>><?=esc($c)?></option><?php endforeach;?></select></div><div><label for="sort">Сначала</label><select id="sort" name="sort"><?php foreach(['popular'=>'С отзывами','price_asc'=>'Дешевле','price_desc'=>'Дороже','duration'=>'Быстрее'] as $k=>$v):?><option value="<?=$k?>" <?=$sort===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></div><button class="primary">Подобрать</button></form>
   <div class="catalog-result"><span>Найдено услуг: <?=count($rows)?></span><?php if($term!==''||$category!==''):?><a href="/services">Сбросить фильтры ×</a><?php endif;?></div>
   <?php if($rows):?><h2 class="sr-only">Каталог услуг</h2><div class="cards"><?=implode('',array_map(fn($s)=>serviceCard($s,true),$rows))?></div><?php else:?><div class="empty-state"><h2>Ничего не нашлось</h2><p>Попробуйте другую формулировку или откройте все услуги.</p><a class="button" href="/services">Все услуги</a></div><?php endif;?>
   <section class="section faq-section"><div><div class="eyebrow">ПЕРЕД ВИЗИТОМ</div><h2>Ответы на вопросы</h2></div><?=faqBlock()?></section>
  <?php });render('Услуги и цены','<div class="wrap page">'.$body.'</div>');
 }
 if($route==='/') {
  $rows=catalogueRows();$recent=query('SELECT r.*,u.name,s.name service_name FROM reviews r JOIN users u ON u.id=r.user_id JOIN services s ON s.id=r.service_id WHERE r.is_published=1 AND s.is_active=1 ORDER BY r.created_at DESC LIMIT 3')->fetchAll();
  $body=fragment(function()use($rows,$recent){?>
   <div class="wrap"><section class="hero"><div class="hero-copy"><div class="eyebrow">ДЕТЕЙЛИНГ-СТУДИЯ · МОСКВА</div><h1>Внимание к деталям.<br>Забота об автомобиле.</h1><p>Чистый салон, выразительный блеск и защита кузова. Выберите уход и запишитесь на удобное время.</p><div class="actions"><a class="button primary" href="/services">Выбрать услугу <span aria-hidden="true">↗</span></a><a class="text-link" href="/about">О нашем подходе →</a></div><div class="hero-facts"><span>Кузов и салон</span><span>Онлайн-запись</span><span>Отзывы после визита</span></div></div><div class="hero-visual"><picture><source type="image/webp" srcset="<?=esc(imageSrcset('/assets/images/apex-detailing-studiya.webp'))?>" sizes="(max-width: 650px) 100vw, 620px"><img src="<?=esc(assetPath('/assets/images/apex-detailing-studiya.jpg'))?>" srcset="<?=esc(imageSrcset('/assets/images/apex-detailing-studiya.jpg'))?>" sizes="(max-width: 650px) 100vw, 620px" alt="Серый автомобиль в светлой студии детейлинга" width="1280" height="853" fetchpriority="high" loading="eager" decoding="async"></picture><div class="hero-caption"><span>APEX DETAILING</span><span>Уход начинается с деталей</span></div></div></section>
   <section class="section"><div class="section-top"><div><div class="eyebrow">ВЫБЕРИТЕ СВОЙ УХОД</div><h2>Три направления. Один подход.</h2></div><a class="text-link" href="/services">Все услуги →</a></div><div class="cards"><?=implode('',array_map('serviceCard',array_slice($rows,0,3)))?></div></section></div>
   <section class="process"><div class="wrap process-row"><div><div class="eyebrow">БЕЗ ЛИШНИХ ШАГОВ</div><h2>От выбора<br>до результата</h2></div><?php foreach([['01','Выберите уход','Сравните состав, время и стоимость услуг.'],['02','Оставьте заявку','Укажите автомобиль и удобное время. Мы согласуем визит.'],['03','Оцените результат','История визитов и отзывы доступны в личном кабинете.']] as $x):?><div class="step"><b><?=$x[0]?></b><div><h3><?=$x[1]?></h3><p><?=$x[2]?></p></div></div><?php endforeach;?></div></section>
   <?php if(function_exists('activePromotions')&&($promos=activePromotions())):?><section class="section wrap"><div class="section-top"><div><div class="eyebrow">БОЛЬШЕ УХОДА ЗА ТУ ЖЕ СУММУ</div><h2>Предложения студии</h2></div><a class="text-link" href="/promotions">Все акции →</a></div><div class="cards" data-promotion-list data-limit="3"><?=implode('',array_map('promotionCard',array_slice($promos,0,3)))?></div></section><?php endif;?>
   <?php if($recent):?><section class="section wrap"><div class="section-top"><div><div class="eyebrow">ОПЫТ ПОСЛЕ ВИЗИТА</div><h2>Клиенты о работе студии</h2></div></div><div class="cards"><?php foreach($recent as $r):?><div class="testimonial"><?=reviewHtml($r)?><a class="text-link" href="/service?id=<?=$r['service_id']?>#reviews"><?=esc($r['service_name'])?> →</a></div><?php endforeach;?></div></section><?php endif;?>
   <section class="section wrap faq-section"><div><div class="eyebrow">ПЕРЕД ВИЗИТОМ</div><h2>Всё, что нужно знать</h2><p>Поможем выбрать уход и подготовиться к визиту.</p><a class="text-link" href="/contacts">Контакты студии →</a></div><?=faqBlock()?></section>
   <section class="cta-section"><div class="wrap"><div><div class="eyebrow">СЛЕДУЮЩИЙ ШАГ</div><h2>Уделите автомобилю внимание</h2><p>Выберите услугу — остальное начнётся с вашей записи.</p></div><a class="button primary" href="/services">Записать автомобиль ↗</a></div></section>
  <?php });render('Детейлинг студия',$body);
 }
 if($route==='/about') {
  $body='<div class="page-intro"><div class="eyebrow">APEX DETAILING</div><h1>Хороший результат<br>начинается с внимания</h1><p>Уход за кузовом, салоном и защитными покрытиями в одном месте.</p></div><div class="contact-grid"><img src="/assets/images/hero.webp" alt="Автомобиль в рабочем пространстве студии" width="1280" height="853"><div><h2>Подбираем уход под задачу</h2><p>Регулярная мойка, восстановление блеска или глубокая очистка салона требуют разного подхода. В каталоге можно заранее узнать состав работ, длительность и цену.</p><h3>Прозрачная история визитов</h3><p>После записи заявка появится в личном кабинете. Там сохраняется согласованная при оформлении стоимость, в том числе по акции.</p><h3>Отзывы после выполненной работы</h3><p>Публикация оценки доступна клиенту после завершённого визита на выбранную услугу.</p><a class="button primary" href="/services">Подобрать уход</a></div></div><section class="section faq-section"><h2>Перед первым визитом</h2>'.faqBlock().'</section>';
  render('О студии','<div class="wrap page">'.$body.'</div>');
 }
 if($route==='/contacts') {
  $body='<div class="page-intro"><div class="eyebrow">НА СВЯЗИ</div><h1>Начнём с вашего автомобиля</h1><p>Выберите услугу онлайн. Администратор согласует время визита по телефону из заявки.</p></div><div class="contact-grid"><div><div class="contact-item"><span class="eyebrow">ВРЕМЯ РАБОТЫ</span><h2>Ежедневно 09:00–20:00</h2><p>Время записи указывается по Москве.</p></div><div class="contact-item"><span class="eyebrow">ЗАПИСЬ В СТУДИЮ</span><h3>Москва · по предварительной записи</h3><p>Адрес и детали визита уточняются при согласовании заявки.</p><a class="button primary" href="/services">Выбрать услугу</a></div><p class="help">Демонстрационный сайт: контактные данные реальной студии не подключены.</p></div><img src="/assets/images/wash.webp" alt="Бережная мойка кузова автомобиля" width="1280" height="853"></div><section class="section faq-section"><h2>Частые вопросы</h2>'.faqBlock().'</section>';
  render('Контакты','<div class="wrap page">'.$body.'</div>');
 }
 return false;
}
