(() => {
 'use strict';
 const config=JSON.parse(document.querySelector('#apex-analytics-config').textContent),scope='apex:'+config.base+':analytics:';
 const button=document.querySelector('#analytics-debug-toggle'),state=document.querySelector('#analytics-debug-state'),table=document.querySelector('#analytics-event-log');
 const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(scope+key))??fallback;}catch{return fallback;}};
 function paint(){
  const debug=read('debug',false)===true;
  button.textContent=debug?'Выключить диагностику':'Включить диагностику';button.setAttribute('aria-pressed',String(debug));
  state.textContent=debug?'Диагностика включена в этом браузере. Выполните действие на сайте и вернитесь к журналу.':'Диагностика выключена. События в журнал не записываются.';
  const events=read('events',[]);table.replaceChildren();
  if(!events.length){const tr=table.insertRow();const cell=tr.insertCell();cell.colSpan=4;cell.textContent='Событий пока нет.';return;}
  for(const event of [...events].reverse()){
   const row=table.insertRow();
   for(const text of [new Date(event.time).toLocaleTimeString('ru-RU',{timeZone:'Europe/Moscow'}),event.name,JSON.stringify(event.params),event.status])row.insertCell().textContent=text;
  }
 }
 button.addEventListener('click',()=>{try{localStorage.setItem(scope+'debug',JSON.stringify(!read('debug',false)));paint();}catch{state.textContent='Браузер запретил локальное хранилище. Разрешите его для диагностики.';}});
 document.querySelector('#analytics-debug-clear').addEventListener('click',()=>{try{localStorage.removeItem(scope+'events');paint();}catch{}});
 window.addEventListener('storage',paint);window.addEventListener('focus',paint);paint();
})();
