(() => {
 'use strict';
 const base=document.body.dataset.appBase||'';
 let observer=null,controller=null,generation=0;
 const labels={native:'Нативная загрузка',io:'Intersection Observer',skeleton:'Skeleton и Observer'};
 const explanations={native:'Браузер сам выбирает момент загрузки фотографий с loading="lazy".',io:'Фотографии начинают загружаться при приближении к экрану на 150 px.',skeleton:'Во время загрузки видна заглушка; фотографии запрашиваются за 200 px до экрана.'};
 const storageKey='apex:'+base+':image-mode';
 function progress(container){
  const node=document.querySelector('[data-image-progress]');if(!node||!container)return;
  const pictures=[...container.querySelectorAll('.lazy-card picture')],ready=pictures.filter(p=>p.dataset.loadState==='loaded').length,failed=pictures.filter(p=>p.dataset.loadState==='error').length;
  node.textContent='Загружено фотографий: '+ready+' из '+pictures.length+(failed?' · Ошибок: '+failed:'. Остальные — при прокрутке.');
 }
 function start(img,container,signal){
  if(img.dataset.loadStarted)return;
  img.dataset.loadStarted='1';const picture=img.closest('picture'),box=img.closest('.card-image');
  const finish=failed=>{
   if(!failed&&(img.currentSrc.startsWith('data:')||img.naturalWidth<=1))return;
   picture.dataset.loadState=failed?'error':'loaded';box?.classList.add('image-ready');img.classList.add('loaded');
   const error=picture.querySelector('.image-error');if(error)error.hidden=!failed;progress(container);
  };
  img.addEventListener('load',()=>finish(false),{signal});img.addEventListener('error',()=>finish(true),{once:true,signal});
  picture.querySelectorAll('source[data-srcset]').forEach(s=>{s.srcset=s.dataset.srcset;delete s.dataset.srcset;});
  if(img.dataset.srcset)img.srcset=img.dataset.srcset;
  img.src=img.dataset.src;delete img.dataset.src;delete img.dataset.srcset;
  if(img.complete&&img.naturalWidth>1)finish(false);
 }
 async function update(container,signal,current){
  try{
   const response=await fetch(base+'/api/services?limit=60&offset=0',{cache:'no-store',signal});if(!response.ok)return;
   const data=await response.json();if(!data.ok||current!==generation)return;
   (container||document).querySelectorAll('[data-service-id]').forEach(card=>{
    const item=data.items.find(x=>x.id===Number(card.dataset.serviceId));if(!item)return;
    const rating=card.querySelector('.card-rating');if(rating)rating.textContent=item.reviews_count?'★ '+item.avg_rating.toFixed(1)+' · отзывов: '+item.reviews_count:'Пока нет отзывов';
    const img=card.querySelector('img');if(img){img.alt=item.alt_text;img.title=item.image_title;}
   });
  }catch{/* The server rendered cards remain usable offline. */}
 }
 function init(mode){
  const container=document.querySelector('[data-lazy-mode]');
  if(!container){if(mode==='native')update(null,undefined,generation);return;}
  observer?.disconnect();controller?.abort();controller=new AbortController();const signal=controller.signal;generation++;
  const current=generation;container.dataset.lazyMode=mode;
  update(container,signal,current);
  if(mode==='native'){
   container.querySelectorAll('.lazy-card picture').forEach(picture=>{
    const img=picture.querySelector('img');const finish=()=>{picture.dataset.loadState=img.naturalWidth>1?'loaded':'error';progress(container);};
    img.addEventListener('load',finish,{signal});img.addEventListener('error',finish,{signal});if(img.complete)finish();
   });progress(container);return;
  }
  const images=[...container.querySelectorAll('img[data-src]')];
  if(!('IntersectionObserver' in window)){images.forEach(img=>start(img,container,signal));progress(container);return;}
  observer=new IntersectionObserver((entries,obs)=>{
   for(const entry of entries)if(entry.isIntersecting){start(entry.target,container,signal);obs.unobserve(entry.target);}
  },{rootMargin:mode==='skeleton'?'200px 0px':'150px 0px',threshold:.01});
  images.forEach(img=>observer.observe(img));progress(container);
 }
 function switchMode(mode,historyMode='push'){
  const container=document.querySelector('[data-lazy-mode]'),template=document.querySelector('template[data-mode-template="'+mode+'"]');
  if(!container||!template||!Object.hasOwn(labels,mode))return;
  observer?.disconnect();controller?.abort();container.replaceChildren(template.content.cloneNode(true));
  for(const tab of document.querySelectorAll('[data-loading-mode]')){
   const active=tab.dataset.loadingMode===mode;tab.classList.toggle('active',active);if(active)tab.setAttribute('aria-current','page');else tab.removeAttribute('aria-current');
  }
  document.querySelector('[data-mode-name]').textContent=labels[mode];document.querySelector('[data-mode-description]').textContent=explanations[mode];
  const url=base+'/catalog/'+mode;
  if(historyMode==='push')history.pushState({apexImageMode:mode},'',url);
  else if(historyMode==='replace')history.replaceState({apexImageMode:mode},'',url);
  document.querySelector('link[rel=canonical]')?.setAttribute('href',location.origin+url);
  document.title='Услуги — '+labels[mode]+' | '+document.body.dataset.siteName;
  try{localStorage.setItem(storageKey,mode);}catch{}
  init(mode);document.dispatchEvent(new CustomEvent('apex:catalog-mode',{detail:{mode}}));
 }
 function bind(){
  const nav=document.querySelector('[data-loading-switcher]');if(!nav)return;
  nav.addEventListener('click',event=>{
   const link=event.target.closest('[data-loading-mode]');if(!link||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
   event.preventDefault();if(link.dataset.loadingMode!==document.querySelector('[data-lazy-mode]').dataset.lazyMode)switchMode(link.dataset.loadingMode);
  });
  document.querySelector('#reload-images')?.addEventListener('click',()=>switchMode(document.querySelector('[data-lazy-mode]').dataset.lazyMode,'none'));
  window.addEventListener('popstate',()=>{const mode=location.pathname.split('/').filter(Boolean).pop();if(Object.hasOwn(labels,mode))switchMode(mode,'none');});
  const container=document.querySelector('[data-lazy-mode]');
  if(location.pathname===base+'/catalog'){
   let saved;try{saved=localStorage.getItem(storageKey);}catch{}
   if(Object.hasOwn(labels,saved)){switchMode(saved,'replace');return;}
  }
  init(container.dataset.lazyMode);
 }
 window.ApexImages={init,bind};
})();
