window.ApexImages.init('skeleton');
