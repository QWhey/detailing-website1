window.ApexImages.bind();
