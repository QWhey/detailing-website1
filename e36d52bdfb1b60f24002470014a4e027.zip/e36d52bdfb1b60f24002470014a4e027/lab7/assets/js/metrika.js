(() => {
 'use strict';
 const node=document.querySelector('#apex-analytics-config');
 if(!node)return;
 const config=JSON.parse(node.textContent),scope='apex:'+config.base+':analytics:';
 const allowed={catalog_view:[],service_view:['service_id','view'],booking_start:['service_id'],booking_submit:['booking_id','service_id','order_price','currency'],review_submit:['service_id','rating']};
 const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(scope+key))??fallback;}catch{return fallback;}};
 const debug=()=>read('debug',false)===true;
 const id=Number(config.counterId),enabled=config.enabled&&/^[1-9][0-9]{0,11}$/.test(config.counterId)&&Number.isSafeInteger(id);
 const log=(name,params,status)=>{
  if(!debug())return;
  const entry={time:new Date().toISOString(),name,params,status};
  try{localStorage.setItem(scope+'events',JSON.stringify([...read('events',[]),entry].slice(-30)));}catch{}
  window.dispatchEvent(new CustomEvent('apex:analytics-event',{detail:entry}));
 };
 if(enabled){
  if(typeof window.ym!=='function'){window.ym=function(){(window.ym.a=window.ym.a||[]).push(arguments);};window.ym.l=Date.now();}
  const source='https://mc.yandex.ru/metrika/tag.js';
  if(![...document.scripts].some(s=>s.src.split('?')[0]===source)){const tag=document.createElement('script');tag.async=true;tag.src=source+'?id='+id;tag.addEventListener('error',()=>log('counter_error',{},'Сеть или блокировщик'));document.head.append(tag);}
  window.dataLayer=window.dataLayer||[];
  window.ym(id,'init',{ssr:true,ecommerce:'dataLayer',clickmap:true,trackLinks:true,accurateTrackBounce:true,webvisor:config.webvisor,triggerEvent:true});
 }
 function goal(name,params={},once=''){
  if(!Object.hasOwn(allowed,name))return false;
  const clean={};
  for(const key of allowed[name]){
   const value=params[key];
   if((key.endsWith('_id')||key==='rating')&&Number.isSafeInteger(Number(value))&&Number(value)>0)clean[key]=Number(value);
   if(key==='view'&&['page','quick'].includes(value))clean[key]=value;
   if(key==='currency'&&value==='RUB')clean[key]=value;
   if(key==='order_price'&&Number.isFinite(Number(value))&&Number(value)>=0)clean[key]=Number(value);
  }
  const key=scope+'once:'+once;
  if(once){try{if(sessionStorage.getItem(key))return false;}catch{}}
  if(enabled){
   try{window.ym(id,'reachGoal',name,clean);if(once){try{sessionStorage.setItem(key,'1');}catch{}}log(name,clean,'Вызов ym');return true;}
   catch{log(name,clean,'Ошибка вызова');return false;}
  }
  log(name,clean,'Счётчик выключен');return false;
 }
 window.ApexAnalytics={goal,enabled,counterId:enabled?id:null};
 for(const event of config.events)goal(event.name,event.params,event.once||'');
 document.addEventListener('click',event=>{
  const link=event.target.closest('a[href]');if(!link)return;
  const url=new URL(link.href,location.href);
  if(url.origin===location.origin&&url.pathname===config.base+'/booking')goal('booking_start',{service_id:Number(url.searchParams.get('id'))});
 });
})();
