'use strict';
const APP_BASE = document.body.dataset.appBase || '';
const menu = document.querySelector('.menu-button');
menu?.addEventListener('click', () => {
  const expanded = menu.getAttribute('aria-expanded') !== 'true';
  menu.setAttribute('aria-expanded', String(expanded));
  document.querySelector('#navlinks').classList.toggle('open', expanded);
});
const dialog = document.querySelector('#quickview');
document.querySelector('.dialog-close')?.addEventListener('click', () => dialog.close());
dialog?.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
document.querySelectorAll('[data-quick]').forEach(button => {
  button.addEventListener('click', async () => {
    const content = document.querySelector('#quick-content');
    content.textContent = 'Загрузка…'; dialog.showModal();
    try {
      const response = await fetch(APP_BASE + '/api/service?id=' + encodeURIComponent(button.dataset.quick));
      const result = await response.json();
      if (!response.ok) throw new Error(result.message);
      window.ApexAnalytics?.goal('service_view',{service_id:Number(button.dataset.quick),view:'quick'});
      content.innerHTML = result.html; // Server-rendered HTML with escaped user content.
      content.querySelectorAll('[data-tab]').forEach(tab => tab.addEventListener('click', () => {
        content.querySelectorAll('[data-tab]').forEach(t => t.setAttribute('aria-selected', String(t === tab)));
        content.querySelectorAll('[data-panel]').forEach(p => { p.hidden = p.dataset.panel !== tab.dataset.tab; });
      }));
    } catch (error) { content.textContent = error.message || 'Не удалось загрузить услугу.'; }
  });
});
const reviewForm = document.querySelector('[data-review-form]');
reviewForm?.addEventListener('submit', async (event) => {
  event.preventDefault();
  const status = reviewForm.querySelector('[data-form-status]');
  const button = reviewForm.querySelector('button');
  button.disabled = true; status.textContent = 'Сохраняем…';
  try {
    const response = await fetch(reviewForm.action, {
      method: 'POST', headers: {Accept: 'application/json'},
      body: new URLSearchParams(new FormData(reviewForm))
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message);
    document.querySelector('[data-review-list]').innerHTML = result.html;
    document.querySelector('[data-rating]').textContent = result.rating;
    const schemaNode = document.querySelector('#service-schema');
    if (schemaNode) { const data = JSON.parse(schemaNode.textContent); if(result.aggregate)data.aggregateRating=result.aggregate;else delete data.aggregateRating; data.review = result.reviews; schemaNode.textContent = JSON.stringify(data); }
    status.className = 'success'; status.textContent = result.message;
    window.ApexAnalytics?.goal('review_submit',{service_id:Number(reviewForm.querySelector('[name=service_id]').value),rating:Number(reviewForm.querySelector('[name=rating]:checked')?.value)});
    button.textContent = 'Обновить отзыв';
  } catch (error) { status.className = 'error'; status.textContent = error.message || 'Ошибка связи с сервером.'; }
  finally { button.disabled = false; }
});
document.querySelectorAll('[data-confirm-delete], [data-confirm]').forEach(form => form.addEventListener('submit', event => {
  if (!confirm(form.dataset.confirm || 'Удалить запись? Это действие нельзя отменить.')) event.preventDefault();
}));

const reviewText = document.querySelector('#review-text');
const updateCount = () => { const node=document.querySelector('[data-character-count]'); if(node)node.textContent=[...reviewText.value].length; };
if(reviewText){reviewText.addEventListener('input',updateCount);updateCount();}
document.querySelectorAll('.navlinks a').forEach(a=>{if(new URL(a.href).pathname===location.pathname)a.setAttribute('aria-current','page');});
