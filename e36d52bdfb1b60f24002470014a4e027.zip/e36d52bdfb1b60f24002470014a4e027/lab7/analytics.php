<?php
// Lab 6: configuration and events shared with Lab 7.
function analyticsSettings(): array {
 static $config;
 if($config===null){
  $config=['counter_id'=>'','site_url'=>'','enabled'=>0,'webvisor'=>0];
  try{$row=query('SELECT counter_id,site_url,enabled,webvisor FROM analytics_settings WHERE id=1')->fetch();if($row)$config=$row;}
  catch(PDOException $e){if($e->getCode()!=='42S02')throw $e;}
 }
 return $config;
}
function analyticsReceipt(int $bookingId,int $serviceId,int $price): void {
 $_SESSION['analytics_receipts'][]=['name'=>'booking_submit','params'=>['booking_id'=>$bookingId,'service_id'=>$serviceId,'order_price'=>$price/100,'currency'=>'RUB'],'once'=>'booking-'.$bookingId];
 $_SESSION['analytics_receipts']=array_slice($_SESSION['analytics_receipts'],-10);
}
function analyticsHead(): string {
 $route=requestRoute();$s=analyticsSettings();
 $private=(bool)preg_match('~^/(?:admin|login|register|account/profile)(?:/|$)~',$route);
 $events=[];
 if(!$private&&http_response_code()<400){
  if($route==='/service'&&ctype_digit((string)($_GET['id']??'')))$events[]=['name'=>'service_view','params'=>['service_id'=>(int)$_GET['id'],'view'=>'page']];
  if($route==='/services')$events[]=['name'=>'catalog_view','params'=>[]];
  if($route==='/account'){$events=array_merge($events,$_SESSION['analytics_receipts']??[]);unset($_SESSION['analytics_receipts']);}
 }
 $config=['counterId'=>(string)$s['counter_id'],'enabled'=>!$private&&((currentUser()['role']??'')!=='admin')&&(bool)$s['enabled'],'webvisor'=>(bool)$s['webvisor']&&!str_starts_with($route,'/account')&&$route!=='/booking','base'=>appBase(),'events'=>$events];
 $json=json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
 $path='/assets/js/metrika.js';$version=substr(hash_file('sha256',__DIR__.$path),0,10);
 return '<script type="application/json" id="apex-analytics-config">'.$json.'</script><script defer src="'.appUrl($path).'?v='.$version.'"></script><link rel="stylesheet" href="'.appUrl('/assets/analytics.css').'?v='.substr(hash_file('sha256',__DIR__.'/assets/analytics.css'),0,10).'">';
}
function analyticsNoscript(): string {
 $s=analyticsSettings();$route=requestRoute();
 if((currentUser()['role']??'')==='admin'||!$s['enabled']||!preg_match('/^[1-9][0-9]{0,11}$/D',(string)$s['counter_id'])||preg_match('~^/(?:admin|login|register|account|booking)(?:/|$)~',$route))return '';
 return '<noscript><div><img src="https://mc.yandex.ru/watch/'.esc($s['counter_id']).'" class="metrika-pixel" alt=""></div></noscript>';
}
function analyticsGoals(): array {
 return [
  ['Просмотр каталога','Посещение страниц',appUrl('/services'),'Открытие страницы услуг'],
  ['Просмотр услуги','Целевое событие','service_view','Страница услуги или успешно загруженный быстрый просмотр'],
  ['Начало записи','Целевое событие','booking_start','Переход по ссылке записи на услугу'],
  ['Запись автомобиля','Целевое событие','booking_submit','Новая запись сохранена транзакцией в БД'],
  ['Отправка отзыва','Целевое событие','review_submit','API подтвердил сохранение отзыва'],
 ];
}
function analyticsRoutes(string $route): bool {
 if(!in_array($route,['/admin/analytics','/admin/analytics/check'],true))return false;
 if(!currentUser())redirect('/admin/login');needAdmin();
 if($route==='/admin/analytics/check'){
  $body='<div class="analytics-intro"><p>Локальная проверка событий в этом браузере. Журнал показывает вызовы сайта, а поступление визитов подтверждается в Яндекс.Метрике.</p><div class="actions"><button class="primary" id="analytics-debug-toggle">Включить диагностику</button><button id="analytics-debug-clear">Очистить журнал</button><a class="button" href="/services" target="_blank" rel="noopener">Открыть каталог ↗</a></div><p id="analytics-debug-state" role="status"></p></div><div class="admin-form-card"><h2>Последние события браузера</h2><div class="table-wrap"><table><thead><tr><th>Время</th><th>Событие</th><th>Параметры</th><th>Передача</th></tr></thead><tbody id="analytics-event-log"></tbody></table></div></div><section class="analytics-guide"><h2>Как подтвердить приём данных</h2><p>Откройте опубликованный сайт без блокировщика, проверьте запросы tag.js и watch в Network. В Метрике откройте «Отладчик» или добавьте к URL сайта параметр _ym_debug=1. Затем проверьте визит в «Сводке» и достижение настроенной цели. Запись «Вызов ym» означает вызов API в браузере, а не подтверждение доставки.</p><a class="button" href="/admin/analytics">Настройки счётчика</a></section><script defer src="'.appUrl('/assets/js/analytics-check.js').'"></script>';
  adminPage('Проверка аналитики',$body,'analytics');
 }
 $v=analyticsSettings();$error='';
 if($_SERVER['REQUEST_METHOD']==='POST'){
  checkCsrf();$v=['counter_id'=>trim((string)($_POST['counter_id']??'')),'site_url'=>rtrim(trim((string)($_POST['site_url']??'')),'/'),'enabled'=>isset($_POST['enabled'])?1:0,'webvisor'=>isset($_POST['webvisor'])?1:0];
  try{
   if($v['counter_id']!==''&&!preg_match('/^[1-9][0-9]{0,11}$/D',$v['counter_id']))throw new AppError(422,'ID счётчика должен содержать от 1 до 12 цифр и начинаться не с нуля.');
   if($v['enabled']&&$v['counter_id']==='')throw new AppError(422,'Укажите ID счётчика перед включением аналитики.');
   $url=parse_url($v['site_url']);
   if($v['site_url']!==''&&(strlen($v['site_url'])>500||!filter_var($v['site_url'],FILTER_VALIDATE_URL)||!in_array($url['scheme']??'',['http','https'],true)||isset($url['query'])||isset($url['fragment'])||isset($url['user'])||isset($url['pass'])))throw new AppError(422,'Укажите полный http(s) адрес сайта без параметров, пароля и фрагмента.');
   if($v['enabled']&&$v['site_url']==='')throw new AppError(422,'Укажите опубликованный адрес сайта для подключения счётчика.');
   query('INSERT INTO analytics_settings(id,counter_id,site_url,enabled,webvisor) VALUES(1,?,?,?,?) ON DUPLICATE KEY UPDATE counter_id=VALUES(counter_id),site_url=VALUES(site_url),enabled=VALUES(enabled),webvisor=VALUES(webvisor)',array_values($v));
   flash('Настройки аналитики сохранены. Проверьте события на опубликованном сайте.');redirect('/admin/analytics');
  }catch(AppError $e){$error=$e->getMessage();}
 }
 $body=fragment(function()use($v,$error){?>
  <div class="split"><div class="admin-form-card"><?=notice($error,true)?><form method="post" class="form-grid"><?=csrf()?><?=field('counter_id','ID счётчика Яндекс.Метрики',$v['counter_id'],'text','inputmode="numeric" pattern="[1-9][0-9]{0,11}" maxlength="12" placeholder="Номер вашего счётчика"')?><?=field('site_url','Адрес опубликованного сайта',$v['site_url'],'url','maxlength="500" placeholder="https://ваш-домен/lab6"')?><label class="analytics-checkbox"><input type="checkbox" name="enabled" value="1" <?=$v['enabled']?'checked':''?>> Включить счётчик на сайте</label><label class="analytics-checkbox"><input type="checkbox" name="webvisor" value="1" <?=$v['webvisor']?'checked':''?>> Вебвизор на публичных страницах</label><p class="help">В админке, входе и регистрации счётчик выключен. В кабинете и форме записи Вебвизор выключен. Имя, телефон, email и текст отзыва не передаются в параметрах целей.</p><button class="primary">Сохранить аналитику</button></form></div><aside class="summary"><div class="eyebrow">ЯНДЕКС.МЕТРИКА</div><h2><?=$v['enabled']&&$v['counter_id']!==''?'Подключение включено':'Счётчик не подключён'?></h2><p>Создайте счётчик для Apex Detailing, укажите адрес сайта и сохраните его ID слева. Дополнительным адресом можно добавить папку lab7.</p><div class="actions"><a class="button small" href="https://metrika.yandex.ru/" target="_blank" rel="noopener">Открыть Метрику ↗</a><a class="button small" href="/admin/analytics/check">Проверка событий</a></div><p class="help">Статус включения не подтверждает приём данных сервисом.</p></aside></div>
  <section class="analytics-guide" id="analytics-goals"><h2>Цели для настройки в Метрике</h2><p>Создайте цели в кабинете счётчика. Для событий скопируйте идентификаторы точно, включая подчёркивания.</p><div class="table-wrap"><table><thead><tr><th>Название</th><th>Тип</th><th>Условие</th><th>Когда учитывается</th></tr></thead><tbody><?php foreach(analyticsGoals() as $goal):?><tr><?php foreach($goal as $cell):?><td><?=esc($cell)?></td><?php endforeach;?></tr><?php endforeach;?></tbody></table></div></section>
  <section class="analytics-guide" id="analytics-filters"><h2>Собственный трафик и фильтры</h2><p>В настройках счётчика включите «Не учитывать мои визиты». Для отдельного IP-фильтра выберите «Исключить трафик», поле «IP-адрес» и свой текущий внешний IP. Эти настройки задаются в Яндекс.Метрике. Они не меняют ранее собранные данные.</p></section>
  <section class="analytics-guide" id="analytics-reports"><h2>Что анализировать после публикации</h2><p>Выберите один период в отчётах «Сводка», «Источники», «Страницы входа», «Страницы выхода» и «Конверсии». Сравните путь от просмотра услуги до записи. Если данных нет, сначала подтвердите загрузку счётчика и доставку визита; пустая выборка не позволяет оценить качество сайта.</p></section>
 <?php });adminPage('Аналитика сайта',$body,'analytics',$error?422:200);
}
