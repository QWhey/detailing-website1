-- Lab 7: repeatable addition to the existing Apex Detailing database.
SET NAMES utf8mb4;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_alt')=0,'ALTER TABLE services ADD COLUMN image_alt VARCHAR(255) NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_title')=0,'ALTER TABLE services ADD COLUMN image_title VARCHAR(255) NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_webp')=0,'ALTER TABLE services ADD COLUMN image_webp VARCHAR(500) NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_jpeg')=0,'ALTER TABLE services ADD COLUMN image_jpeg VARCHAR(500) NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_width')=0,'ALTER TABLE services ADD COLUMN image_width SMALLINT UNSIGNED NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_height')=0,'ALTER TABLE services ADD COLUMN image_height SMALLINT UNSIGNED NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
CREATE TABLE IF NOT EXISTS settings (`key` VARCHAR(64) PRIMARY KEY,`value` TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO settings(`key`,`value`) VALUES
('site_name','Apex Detailing'),('site_description','Детейлинг-студия Apex Detailing: уход за кузовом и салоном, защитные покрытия и онлайн-запись.'),('site_logo','/assets/brand/apex-detailing-logo.svg'),('site_logo_alt','Apex Detailing — логотип детейлинг-студии');
UPDATE services SET image_webp='/assets/images/detailing-moyka-avtomobilya.webp',image_jpeg='/assets/images/detailing-moyka-avtomobilya.jpg',image_width=1280,image_height=853 WHERE image='wash.webp' AND (image_webp IS NULL OR image_webp='');
UPDATE services SET image_webp='/assets/images/polirovka-kuzova.webp',image_jpeg='/assets/images/polirovka-kuzova.jpg',image_width=1280,image_height=853 WHERE image='polish.webp' AND (image_webp IS NULL OR image_webp='');
UPDATE services SET image_webp='/assets/images/himchistka-salona.webp',image_jpeg='/assets/images/himchistka-salona.jpg',image_width=1280,image_height=853 WHERE image='interior.webp' AND (image_webp IS NULL OR image_webp='');
UPDATE services SET image_webp='/assets/images/apex-detailing-studiya.webp',image_jpeg='/assets/images/apex-detailing-studiya.jpg',image_width=1280,image_height=853 WHERE image='hero.webp' AND (image_webp IS NULL OR image_webp='');
UPDATE services SET image_alt=CONCAT(name,' — уход за автомобилем в студии Apex Detailing') WHERE image_alt IS NULL OR image_alt='';
UPDATE services SET image_title=name WHERE image_title IS NULL OR image_title='';
UPDATE services SET image_width=1280,image_height=853 WHERE image_width IS NULL OR image_height IS NULL;
