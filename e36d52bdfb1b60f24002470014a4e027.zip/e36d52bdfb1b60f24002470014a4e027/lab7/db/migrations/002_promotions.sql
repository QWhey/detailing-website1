-- Apply to the existing Lab 4 database. Does not delete users, visits or reviews.
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS promotions (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 service_id INT UNSIGNED NOT NULL,
 title VARCHAR(160) NOT NULL, description TEXT NOT NULL,
 image VARCHAR(120) NOT NULL,
 type ENUM('minute','day','week','month') NOT NULL,
 sale_price INT UNSIGNED NOT NULL,
 starts_at BIGINT UNSIGNED NOT NULL, ends_at BIGINT UNSIGNED NOT NULL,
 is_active TINYINT UNSIGNED NOT NULL DEFAULT 0,
 FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE,
 KEY idx_promo_window(is_active,ends_at,starts_at),
 KEY idx_promo_service(service_id), CHECK(sale_price>0), CHECK(ends_at>starts_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SET @statement = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bookings' AND COLUMN_NAME='base_price')=0,
 'ALTER TABLE bookings ADD base_price INT UNSIGNED NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE migration FROM @statement; EXECUTE migration; DEALLOCATE PREPARE migration;
UPDATE bookings SET base_price=price WHERE base_price=0;
SET @statement = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bookings' AND COLUMN_NAME='promotion_title')=0,
 'ALTER TABLE bookings ADD promotion_title VARCHAR(160) NOT NULL DEFAULT ""', 'SELECT 1');
PREPARE migration FROM @statement; EXECUTE migration; DEALLOCATE PREPARE migration;
SET @statement = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bookings' AND COLUMN_NAME='promotion_id')=0,
 'ALTER TABLE bookings ADD promotion_id INT UNSIGNED NULL', 'SELECT 1');
PREPARE migration FROM @statement; EXECUTE migration; DEALLOCATE PREPARE migration;
SET @statement = IF((SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND TABLE_NAME='bookings' AND CONSTRAINT_NAME='fk_booking_promotion')=0,
 'ALTER TABLE bookings ADD CONSTRAINT fk_booking_promotion FOREIGN KEY(promotion_id) REFERENCES promotions(id) ON DELETE SET NULL', 'SELECT 1');
PREPARE migration FROM @statement; EXECUTE migration; DEALLOCATE PREPARE migration;
