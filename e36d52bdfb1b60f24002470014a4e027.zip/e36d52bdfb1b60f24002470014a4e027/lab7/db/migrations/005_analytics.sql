-- Add Lab 6 analytics settings without resetting existing settings or records.
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS analytics_settings (
 id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
 counter_id VARCHAR(12) NOT NULL DEFAULT '',
 site_url VARCHAR(500) NOT NULL DEFAULT '',
 enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
 webvisor TINYINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO analytics_settings(id,counter_id,site_url,enabled,webvisor) VALUES(1,'113733671','http://o92999hi.beget.tech/practical-pages/lab7',1,1);
