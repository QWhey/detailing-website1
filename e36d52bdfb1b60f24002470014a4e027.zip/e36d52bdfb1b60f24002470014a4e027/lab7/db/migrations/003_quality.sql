-- Existing Apex database only. Repeatable migration, no data deletion.
SET NAMES utf8mb4;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='is_active')=0,'ALTER TABLE services ADD COLUMN is_active TINYINT UNSIGNED NOT NULL DEFAULT 1','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='reviews' AND COLUMN_NAME='is_published')=0,'ALTER TABLE reviews ADD COLUMN is_published TINYINT UNSIGNED NOT NULL DEFAULT 1','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
