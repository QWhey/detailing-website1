-- Import inside an EXISTING empty Beget database. No CREATE DATABASE or USE.
SET NAMES utf8mb4;
CREATE TABLE users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(80) NOT NULL, email VARCHAR(160) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('customer','admin') NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE services (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL, description TEXT NOT NULL, details TEXT NOT NULL,
 price INT UNSIGNED NOT NULL, duration SMALLINT UNSIGNED NOT NULL,
 image VARCHAR(120) NOT NULL, category VARCHAR(40) NOT NULL,
 is_active TINYINT UNSIGNED NOT NULL DEFAULT 1,
 CHECK(price>0), CHECK(duration>0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE bookings (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL, service_id INT UNSIGNED NOT NULL,
 car VARCHAR(100) NOT NULL, phone VARCHAR(24) NOT NULL,
 visit_at BIGINT UNSIGNED NOT NULL,
 status ENUM('new','completed','cancelled') NOT NULL DEFAULT 'new',
 price INT UNSIGNED NOT NULL, request_token VARCHAR(64) NOT NULL UNIQUE,
 created_at BIGINT UNSIGNED NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(service_id) REFERENCES services(id),
 KEY idx_booking_owner(user_id,service_id,status), CHECK(price>0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE reviews (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 service_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL,
 rating TINYINT UNSIGNED NOT NULL, text TEXT NOT NULL,
 is_published TINYINT UNSIGNED NOT NULL DEFAULT 1,
 created_at BIGINT UNSIGNED NOT NULL,
 UNIQUE KEY uq_review(user_id,service_id),
 FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 KEY idx_reviews_service(service_id,created_at),
 CHECK(rating BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Apply to the existing Lab 4 database. Does not delete users, visits or reviews.
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS promotions (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 service_id INT UNSIGNED NOT NULL,
 title VARCHAR(160) NOT NULL, description TEXT NOT NULL,
 image VARCHAR(120) NOT NULL,
 type ENUM('minute','day','week','month') NOT NULL,
 sale_price INT UNSIGNED NOT NULL,
 starts_at BIGINT UNSIGNED NOT NULL, ends_at BIGINT UNSIGNED NOT NULL,
 is_active TINYINT UNSIGNED NOT NULL DEFAULT 0,
 FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE,
 KEY idx_promo_window(is_active,ends_at,starts_at),
 KEY idx_promo_service(service_id), CHECK(sale_price>0), CHECK(ends_at>starts_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SET @statement = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bookings' AND COLUMN_NAME='base_price')=0,
 'ALTER TABLE bookings ADD base_price INT UNSIGNED NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE migration FROM @statement; EXECUTE migration; DEALLOCATE PREPARE migration;
UPDATE bookings SET base_price=price WHERE base_price=0;
SET @statement = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bookings' AND COLUMN_NAME='promotion_title')=0,
 'ALTER TABLE bookings ADD promotion_title VARCHAR(160) NOT NULL DEFAULT ""', 'SELECT 1');
PREPARE migration FROM @statement; EXECUTE migration; DEALLOCATE PREPARE migration;
SET @statement = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='bookings' AND COLUMN_NAME='promotion_id')=0,
 'ALTER TABLE bookings ADD promotion_id INT UNSIGNED NULL', 'SELECT 1');
PREPARE migration FROM @statement; EXECUTE migration; DEALLOCATE PREPARE migration;
SET @statement = IF((SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=DATABASE() AND TABLE_NAME='bookings' AND CONSTRAINT_NAME='fk_booking_promotion')=0,
 'ALTER TABLE bookings ADD CONSTRAINT fk_booking_promotion FOREIGN KEY(promotion_id) REFERENCES promotions(id) ON DELETE SET NULL', 'SELECT 1');
PREPARE migration FROM @statement; EXECUTE migration; DEALLOCATE PREPARE migration;

-- Lab 7: repeatable addition to the existing Apex Detailing database.
SET NAMES utf8mb4;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_alt')=0,'ALTER TABLE services ADD COLUMN image_alt VARCHAR(255) NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_title')=0,'ALTER TABLE services ADD COLUMN image_title VARCHAR(255) NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_webp')=0,'ALTER TABLE services ADD COLUMN image_webp VARCHAR(500) NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_jpeg')=0,'ALTER TABLE services ADD COLUMN image_jpeg VARCHAR(500) NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_width')=0,'ALTER TABLE services ADD COLUMN image_width SMALLINT UNSIGNED NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
SET @apex_sql=IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='services' AND COLUMN_NAME='image_height')=0,'ALTER TABLE services ADD COLUMN image_height SMALLINT UNSIGNED NULL','SELECT 1');
PREPARE apex_migration FROM @apex_sql; EXECUTE apex_migration; DEALLOCATE PREPARE apex_migration;
CREATE TABLE IF NOT EXISTS settings (`key` VARCHAR(64) PRIMARY KEY,`value` TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO settings(`key`,`value`) VALUES
('site_name','Apex Detailing'),('site_description','Детейлинг-студия Apex Detailing: уход за кузовом и салоном, защитные покрытия и онлайн-запись.'),('site_logo','/assets/brand/apex-detailing-logo.svg'),('site_logo_alt','Apex Detailing — логотип детейлинг-студии');
UPDATE services SET image_webp='/assets/images/detailing-moyka-avtomobilya.webp',image_jpeg='/assets/images/detailing-moyka-avtomobilya.jpg',image_width=1280,image_height=853 WHERE image='wash.webp' AND (image_webp IS NULL OR image_webp='');
UPDATE services SET image_webp='/assets/images/polirovka-kuzova.webp',image_jpeg='/assets/images/polirovka-kuzova.jpg',image_width=1280,image_height=853 WHERE image='polish.webp' AND (image_webp IS NULL OR image_webp='');
UPDATE services SET image_webp='/assets/images/himchistka-salona.webp',image_jpeg='/assets/images/himchistka-salona.jpg',image_width=1280,image_height=853 WHERE image='interior.webp' AND (image_webp IS NULL OR image_webp='');
UPDATE services SET image_webp='/assets/images/apex-detailing-studiya.webp',image_jpeg='/assets/images/apex-detailing-studiya.jpg',image_width=1280,image_height=853 WHERE image='hero.webp' AND (image_webp IS NULL OR image_webp='');
UPDATE services SET image_alt=CONCAT(name,' — уход за автомобилем в студии Apex Detailing') WHERE image_alt IS NULL OR image_alt='';
UPDATE services SET image_title=name WHERE image_title IS NULL OR image_title='';
UPDATE services SET image_width=1280,image_height=853 WHERE image_width IS NULL OR image_height IS NULL;

-- Add Lab 6 analytics settings without resetting existing settings or records.
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS analytics_settings (
 id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
 counter_id VARCHAR(12) NOT NULL DEFAULT '',
 site_url VARCHAR(500) NOT NULL DEFAULT '',
 enabled TINYINT UNSIGNED NOT NULL DEFAULT 0,
 webvisor TINYINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT IGNORE INTO analytics_settings(id,counter_id,site_url,enabled,webvisor) VALUES(1,'113733671','http://o92999hi.beget.tech/practical-pages/lab7',1,1);
