-- Demo periods start when imported, not on a fixed calendar date.
SET @now = UNIX_TIMESTAMP();
INSERT INTO promotions(service_id,title,description,image,type,sale_price,starts_at,ends_at,is_active) VALUES
(1,'Мойка — пять минут выгоды','Запишитесь на детейлинг-мойку по специальной цене в течение пяти минут.','wash.webp','minute',190000,@now,@now+300,1),
(2,'Блеск кузова — предложение дня','Полировка кузова с выгодой 2 000 рублей. Предложение действует 24 часа.','polish.webp','day',1000000,@now,@now+86400,1),
(3,'Чистый салон — выгода недели','Химчистка салона со скидкой. Выберите удобный день для визита.','interior.webp','week',650000,@now,@now+604800,1),
(4,'Керамика — цена месяца','Защитное покрытие кузова по сниженной цене в течение 30 дней.','polish.webp','month',1500000,@now,@now+2592000,1);
